#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys

def foo():
    print 'I am a foo.'


if __name__ == '__main__':
    print 'foo.__module__ =', foo.__module__
    print 'sys.modules[foo.__module__] =', sys.modules[foo.__module__]
    print
    getattr(sys.modules[foo.__module__], 'foo')()

