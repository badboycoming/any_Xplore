#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# NOTE: classic class not support super
##############################################################################

"""
=================================================== RESTART: Shell ===================================================
>>>
>>> class ClassicClass:
	def __init__(self, name, age):
		self.name = name
		self.age = age


>>> class DriveClass(ClassicClass):
	def __init__(self, salary, name, age):
		super(self.__class__, self).__init(name, age)
		self.salary = salary


>>> dc = DriveClass(2800, 'Li Lei', 12)

Traceback (most recent call last):
  File "<pyshell#108>", line 1, in <module>
    dc = DriveClass(2800, 'Li Lei', 12)
  File "<pyshell#107>", line 3, in __init__
    super(self.__class__, self).__init(name, age)
TypeError: super() argument 1 must be type, not classobj
>>>
=================================================== RESTART: Shell ===================================================
>>>
>>> class ClassicClass:
	def __init__(self, name, age):
		self.name = name
		self.age = age


>>> class DriveClass(ClassicClass):
	def __init__(self, salary, name, age):
		ClassicClass.__init__(self, name, age)
		self.salary = salary


>>> dc = DriveClass(2800, 'Li Lei', 12)
>>> dc.name
'Li Lei'
>>> dc.age
12
>>> dc.salary
2800
>>>
=================================================== RESTART: Shell ===================================================
>>>
>>> class NewClass(object):
	def __init__(self, name, age):
		self.name = name
		self.age = age


>>> class DriveClass(NewClass):
	def __init__(self, salary, name, age):
		super(self.__class__, self).__init__(name, age)
		self.salary = salary


>>> dc = DriveClass(2800, 'Li Lei', 12)
>>> dc.name
'Li Lei'
>>> dc.age
12
>>> dc.salary
2800
>>>
=================================================== RESTART: Shell ===================================================
"""



