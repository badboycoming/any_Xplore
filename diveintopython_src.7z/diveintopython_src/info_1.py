#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Purpose: should replaced.
##############################################################################

def info(object, spacing=15, collapse=1):
    methodList = [item for item in [method for method in dir(object) if callable(getattr(object, method))] if not item.startswith('_')]
    #processFunc = collapse and (lambda s: ' '.join(s.split())) or (lambda s: s)
    processFunc = (lambda s: ' '.join(s.split())) if collapse else (lambda s: s)
    print '\n'.join(['%s %s' % (method.ljust(spacing), processFunc(str(getattr(object, method).__doc__))) for method in methodList])

