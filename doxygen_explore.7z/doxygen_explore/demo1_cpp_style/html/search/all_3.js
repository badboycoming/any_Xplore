var searchData=
[
  ['handler',['handler',['../class_cpp_style___test.html#ad3b1003503366a0fe557f3d8da8c58f8',1,'CppStyle_Test']]]
];
