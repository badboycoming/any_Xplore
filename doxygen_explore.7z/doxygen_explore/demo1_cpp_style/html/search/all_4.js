var searchData=
[
  ['publicvar',['publicVar',['../class_cpp_style___test.html#a4ef200375ef315f5c3f6be5f61799c2b',1,'CppStyle_Test']]]
];
