/// A more elaborate class description.

class CppStyle_Test
{
    public:
        
        enum TEnum {
            TVal1,  ///< Enum value TVal1.
            TVal2,  ///< Enum value TVal2.
            TVal3   ///< Enum value TVal3.
        }

        *enumPtr,
        enumVar;

    ///@sa ~CppStyle_Test()
    CppStyle_Test();

    ///@sa CppStyle_Test()
    ~CppStyle_Test();

    ///@param a an integer argument.
    ///@param s an constant character pointer.
    ///@return The test results.
    int testMe(int a, const char * s);

    ///@param c1 the first argument.
    ///@param c2 the second argument.
    virtual void testMeToo(char c1, char c2) = 0;

    int publicVar;
    int (*handler) (int a, int b);
};



