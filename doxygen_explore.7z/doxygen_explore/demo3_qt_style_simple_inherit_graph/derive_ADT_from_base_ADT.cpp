//----------------------------------------------------------------------------
// Purpose:
// Date: 2015/12/26 ����
//----------------------------------------------------------------------------

//! ADT explorer.
/*!
 * To demo how to derive from ADT.
 */

#include <iostream>
using namespace std;

enum COLOR {Red, Green, Blue, Yellow, White, Black, Brown};

/*!
 * The Base ADT class.
 */
class Animal
{
    public:
        /*!
         * @param age an integer.
         * @sa ~Animal()
         * */
        Animal(int age):itsAge(age) {cout << "Animal constructor" << endl;}
        virtual ~Animal() {cout << "Animal destructor" << endl;}

        /*!
         * @param age an integer.
         */
        virtual void setAge(int age) {itsAge = age;}

        /*!
         * @return an integer.
         */
        virtual int getAge() const {return itsAge;}

        virtual void sleep() const = 0;
        virtual void eat() const = 0;
        virtual void reproduce() const = 0;
        virtual void move() const = 0;
        virtual void speak() const = 0;
    private:
        int itsAge;
};

/*! 
 * The second level ADT class.
 */
class Mammal: public Animal  // NOTE, Mammal not cover all pure virtual function in base class Animal,
                             // so Mammal also ADT, cannot create instance from it.
{
    public:
        /*!
         * @param age an integer.
         * @sa ~Mammal()
         */
        Mammal(int age):Animal(age) {cout << "Mammal constructor" << endl;}
        virtual ~Mammal() {cout << "Mammal destructor" << endl;}

        virtual void reproduce() const {cout << "Mammal reproduction!" << endl;}

    private:
};

/*! 
 * Derive from base ADT class.
 */
class Fish: public Animal  // NOTE, due to fish derive from Animal, so need to cover all pure virtual function
{
    public:
        /*!
         * @param age an integer.
         * @sa ~Fish()
         */
        Fish(int age):Animal(age) {cout << "Fish constructor" << endl;}
        virtual ~Fish() {cout << "Fish destructor" << endl;}

        virtual void sleep() const {cout << "fish sleep" << endl;}
        virtual void eat() const {cout << "fish eat" << endl;}
        virtual void reproduce() const {cout << "fish reproduction!" << endl;}
        virtual void move() const {cout << "fish move" << endl;}
        virtual void speak() const {}  // NOTE cover the pure virtual function, even this function is empty
    private:
};

/*! 
 * Derive from second level ADT class.
 */
class Horse: public Mammal  // NOTE, Horse derive from Mammal, it at least need to covers all other prue virtual function
{
    public:
        /*!
         * @param age an integer.
         * @param color an COLOR.
         * @sa ~Horse()
         */
        Horse(int age, COLOR color):Mammal(age), itsColor(color) {cout << "Horse constructor" << endl;}
        virtual ~Horse() {cout << "Horse destructor" << endl;}

        virtual void speak() const {cout << "Horse speak" << endl;}
        virtual void sleep() const {cout << "Horse sleep" << endl;}
        virtual void eat() const {cout << "Horse eat" << endl;}
        virtual void move() const {cout << "Horse move" << endl;}
        // NOTE, here not cover the "reproduce" method, due to it have covered in Mammal class

    private:
        COLOR itsColor;
};

/*! 
 * Derive from second level ADT class.
 */
class Dog: public Mammal
{
    public:
        /*!
         * @param age an integer.
         * @param color an COLOR
         */
        Dog(int age, COLOR color):Mammal(age), itsColor(color) {cout << "Dog constructor" << endl;}
        virtual ~Dog() {cout << "Dog destructor" << endl;}

        virtual void speak() const {cout << "Dog speak" << endl;}
        virtual void sleep() const {cout << "Dog sleep" << endl;}
        virtual void eat() const {cout << "Dog eat" << endl;}
        virtual void move() const {cout << "Dog move" << endl;}
        virtual void reproduce() const {cout << "Dog reproduction!" << endl;}

    private:
        COLOR itsColor;
};

int main()
{
    Animal * pAnimal = 0;
    int choice;
    bool fQuit = false;

    while(1)
    {
        cout << "(1) Dog  (2) Horse  (3) Fish  (0) Quit: ";
        cin >> choice;

        switch(choice)
        {
            case 1: pAnimal = new Dog(5, White); break;
            case 2: pAnimal = new Horse(4, Black); break;
            case 3: pAnimal = new Fish(5); break;
            default: fQuit = true; break;
        }

        if(fQuit)
        {
            break;
        }

        pAnimal->speak();
        pAnimal->eat();
        pAnimal->reproduce();
        pAnimal->move();
        pAnimal->sleep();

        delete pAnimal;
        pAnimal = 0;
        cout << endl;
    }

    return 0;
}


