// test cmake, demo1.

#include <stdio.h>
#include <stdlib.h>  // atof(), atoi()

double power(double base, int exp)
{
    if (exp == 0)
        return 1;

    double result = base;
    int i;
    for (i = 1; i < exp; i++)
        result *= base;

    return result;
}

int main(int argc, char * argv[])
{
    if (argc < 3)
    {
        printf("Usage: %s base exp\n", argv[0]);
        return -1;
    }

    double base = atof(argv[1]);
    int exp = atoi(argv[2]);
    double result = power(base, exp);
    printf("%g ^ %d = %g\n", base, exp, result);

    return 0;
}



