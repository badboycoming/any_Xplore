#define USE_MYMATH
