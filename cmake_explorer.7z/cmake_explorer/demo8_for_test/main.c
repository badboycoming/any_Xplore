// test cmake, demo5.

#include <stdio.h>
#include <stdlib.h>  // atof(), atoi()
#include "config.h"


#ifdef USE_MYMATH
#include "math/mathFunc.h"
#else
#include <math.h>  // pow()
#endif

int main(int argc, char * argv[])
{
    if (argc < 3)
    {
        printf("Usage: %s base exp\n", argv[0]);
        return -1;
    }

    double base = atof(argv[1]);
    int exp = atoi(argv[2]);

#ifdef USE_MYMATH
    printf("Now with user defined math lib.\n");
    double result = power(base, exp);
#else
    printf("Now with C standard math lib.\n");
    //double result = pow(base, exp);  // NOTE, under Linux, should add -lm, or else cannot compile succeed
    double result = base + exp; // here is a stub, for above reason
#endif

    printf("%g ^ %d = %g\n", base, exp, result);
    return 0;
}



