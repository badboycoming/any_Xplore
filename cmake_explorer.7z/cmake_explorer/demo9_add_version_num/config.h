/* #undef USE_MYMATH */

// for version info
#define Demo_VERSION_MAJOR 0
#define Demo_VERSION_MINOR 1
