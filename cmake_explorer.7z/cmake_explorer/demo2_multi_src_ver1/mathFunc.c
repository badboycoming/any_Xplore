
double power(double base, int exp)
{
    if (exp == 0)
        return 1;

    double result = base;
    int i;
    for (i = 1; i < exp; i++)
        result *= base;

    return result;
}

