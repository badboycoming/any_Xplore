
double power(double base, int exp);
