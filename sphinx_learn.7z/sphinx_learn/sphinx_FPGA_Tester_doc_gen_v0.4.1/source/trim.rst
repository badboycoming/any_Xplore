Trim
====
Describe how to use trim functional.

Open Trim Window
----------------

.. image:: _static/20.png

- Trim window as,

.. image:: _static/21.png

Functional Overview
-------------------

- Load and Save file buttons overview,

.. NOTE:: can Load **.xlsx** or **.xls** file, but only can save as **.xls**, due to current software not support write to **.xlsx** format.

.. image:: _static/22.png

- Write to chip buttons overview,

.. image:: _static/23.png

- Search box overview,

.. image:: _static/24.png

Load File
---------

- Click the Button **Load trim table from file**,

.. image:: _static/25.png

- Open the file selection window, two types of file can be loaded, **.xlsx** or **.xls**,

.. image:: _static/26.png

- Select one file and open, trim window as,

.. NOTE:: only the **User_Set** column can be modified, other columns are read only.

.. image:: _static/27.png

Save File
---------

- When make some changes in the **User_Set** column, the background of  the changed cells highlight with **Green**,

.. image:: _static/28.png

- If you want to save the new table to a file, just click Button **Save trim table to file**,

.. image:: _static/29.png
 
- Open the save file window, the default save format is **.xls**,

.. image:: _static/30.png

Write Default Whole Table to Chip
---------------------------------

- Click the Button **Write default whole table to chip**,

.. image:: _static/31.png

- Pop up a confirm window, click **Ok**,

.. image:: _static/32.png

- Start writing, Notice the pop-up window title change to **Write process ongoing**, when write done, the pop-up window auto closed,

.. image:: _static/33.png

- At the same time, in the main window, System Output display the write log,

.. NOTE:: Here is write reg from 0 to 675 with **DEFAULT_DAC** column values.

.. image:: _static/34.png

continue,

.. image:: _static/35.png

Write Modified Whole Table to Chip
----------------------------------

- Click the Button **Write modified whole table to chip**,

.. image:: _static/36.png

- Notice the changed cells in **User_Set** column highlight with **Green**, means these values have not write to chip,

.. image:: _static/37.png

- Pop up a confirm window, click **Ok**,

.. image:: _static/38.png

- Start writing, Notice the pop-up window title change to **Write process ongoing**, when write done, the pop-up window auto closed,

.. image:: _static/39.png

- At the same time, in the main window, System Output display the write log, 
  
.. NOTE:: Here is write reg from 0 to 675 with **User_Set** column values.

.. image:: _static/40.png

continue,

.. image:: _static/41.png

- Notice when write done, the highlight changed cells turn into **Blue** color,

.. image:: _static/42.png

Write Several Modified Values to Chip
-------------------------------------

- Click the Button **Write modified values to chip**,
  
.. image:: _static/43.png

- Notice the changed cells in **User_Set** column highlight with **Green**, means these values have not write to chip,
  as following, the change affect the reg **0**, **1**, **6**, **7**,

.. image:: _static/44.png

- Pop up a confirm window, click **Ok**,

.. image:: _static/45.png

- Start writing, Notice the pop-up window title change to **Write process ongoing**, when write done,
  the pop-up window auto closed,

.. image:: _static/46.png

- At the same time, in the main window, System Output display the write log, 
  
.. NOTE:: Here is write affected reg 0, 1, 6, 7.

.. image:: _static/47.png

- Notice when write done, the highlight changed cells turn into **Blue** color, 

.. image:: _static/48.png

Search
------

- In the Search text window, type part of the string of **REG_NAME**, press **Enter**, will highlight the matched row,

.. NOTE:: continue press the **Enter**, jump to next, when reach the last one, the pressed Enter have no effect one time, if press again, start from the beginning again.

.. image:: _static/49.png




