Run a command
=============
Describe run a command with command line.

Input command and run
---------------------

- Input a command,

.. image:: _static/10.png

- Modify command parameters, then click **Run** or just press **Enter**,

.. image:: _static/11.png

- Run result as following,

.. image:: _static/12.png



