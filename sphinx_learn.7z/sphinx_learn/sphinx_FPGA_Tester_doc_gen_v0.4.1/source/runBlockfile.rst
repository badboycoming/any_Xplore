Run a test block file
=====================
Describe run a test block file with command line.

Test block file style
---------------------

- A test block file \*.tb maybe as following,

.. image:: _static/13.png

Specify a test block file and run
---------------------------------

- Click the Open button to specify a test block file,

.. image:: _static/14.png

- Click **Run**,

.. image:: _static/15.png

- Run result as following,

.. image:: _static/16.png



