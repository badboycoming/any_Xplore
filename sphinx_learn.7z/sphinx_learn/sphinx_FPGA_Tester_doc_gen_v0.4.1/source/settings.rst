Settings
========
Describe basic settings of FPGA Tester.

Basic options overview
----------------------

.. image:: _static/5.png  

Settings options overview
-------------------------

.. image:: _static/6.png  

Host socket setting
-------------------

- User should set the IP and Port according to your FPGA Tester Hardware device, here just an example.

.. image:: _static/7.png

Log properties setting
----------------------

- User should specify a folder for the log storage, and choose a proper log level. The Detailed Grade: DEBUG > LITE > INFO.

.. image:: _static/8.png

Address mapping file setting
----------------------------

- User should specify a valid Address Mapping file.

.. image:: _static/9.png




