Extend the available command list
=================================
Describe how to extend the valid command list after installation.

Valid command coding style
--------------------------

- Note, your command should have valid coding style as following,
  
.. image:: _static/17.png

Add new public command
----------------------

- Add new public command into file: **C:\\Program Files (x86)\\FPGA Tester\\test_block_py\\cmdline.py**,
  restart the GUI again,

.. image:: _static/18.png

Add new private command
-----------------------

- Add new private functions into **C:\\Program Files (x86)\\FPGA Tester\\test_block_py\\cmdline.py**, 
  make sure these functions name begin with **_** as following,

.. image:: _static/19.png






