Install
=======
Describe how to install the FPGA Tester into your **Windows** PC.

.. NOTE:: Due to the company policy, you need IT help to do following steps.

Get package and install
-----------------------

- Get installation package **FPGA Tester Installer.exe** from **Y:\\PETE\\FPGA_Tester_Tools**,

- Just double click to install it, default location is **C:\\Program Files (x86)\\FPGA Tester** for 64-bit OS,
  and **C:\\Program Files\\FPGA Tester** for 32-bit OS.

Modify the installation folder properties
-----------------------------------------

- Right click the installation folder **FPGA Tester**, Select **Properties**,

.. image:: _static/1.png  

- Select **Edit**

.. image:: _static/2.png  

- Select **Users(xxxxxxxx\Users)**, check all the **Users Permissions**, click **Ok**,

.. image:: _static/3.png  

- Now, FPGA Teser GUI Program installed Ok,

.. image:: _static/4.png  



