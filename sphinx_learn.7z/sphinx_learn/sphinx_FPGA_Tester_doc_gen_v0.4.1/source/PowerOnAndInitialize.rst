Power On and Initialize the Hardware Device
===========================================
After power on the device, should initialize it. 
(**If device has been initialized and not powered off, ignore this step.**)

Power On
--------

- Make sure all peripherals installed is ok, such as the **power line**, **network cable**, etc.

- Just push the power button on the hardware device.


Initialize the FPGA Tester hardware device
------------------------------------------

- Open the FPGA Tester GUI program, click **Open**,

.. image:: _static/9_1.png

- Double-click the folder **test_block_tb** (the absolute path is: **C:\\Program Files (x86)\\FPGA Tester\\test_block_tb**),

.. image:: _static/9_2.png

- Select **test_initial.tb**, click **Open**,

.. image:: _static/9_3.png

- Click **Run**,

.. image:: _static/9_4.png

- System output as following, means the device initialized ok,

.. image:: _static/9_5.png



