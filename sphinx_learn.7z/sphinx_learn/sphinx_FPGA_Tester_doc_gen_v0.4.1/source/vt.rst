VT
==
Describe how to use vt functional.

Open VT Window
--------------

.. image:: _static/50.png

- VT window as,  

.. image:: _static/51.png

VT 
--

- Commands can be selected from the pull down list,

.. image:: _static/52.png

- The valid parameter fields will enable or disable varying with the selected command,

.. image:: _static/53.png

- You can Save, Delete, Clear the parameter item,

  * When set done each fields and want to save the setting, click the **Save** button.
  * When want to delete one saved item, select that item, click the **Delete** button. 
  * When want to clear all saved items of current command, click the **Clear** button.
  
.. image:: _static/54.png

- When parameter list set done, select one or more of the items you want to plot, as following select **test_page0** and **test_page1**,

.. image:: _static/54_1.png
  
- Click the **Get VT Distribution** button to draw the vt distribution of the selected items of current parameter list,

.. image:: _static/55.png

- The button turn **Red**, and the label turn into **Running** means the background process is ongoing, 

.. NOTE:: Due to many send/receive command/data, so the process is a little slow, and the Window maybe no response for some time, just wait.

.. image:: _static/56.png

- When draw done, as following example there are two settings curve for the command **tm_corecell_vt**,

.. image:: _static/57.png

- You can adjust the plot location and size, just click following **Pane** button,

  * Hold on the **left** mouse button **move plot location**, at the same time if hold on press key **X** or key **Y**, plot will **move** only along with the **X-axis** or **Y-axis**.
  * Hold on the **right** mouse button to **adjust plot size**, at the same time if hold on press key **X** or key **Y**, plot will **resize** only along with the **X-axis** or **Y-axis**.  
    
.. image:: _static/58.png

- You can save the plot, just click following **Save** button, and select a saved type, such as **png**, **pdf**, etc.  

.. image:: _static/59.png

VT By Bit
---------

All Settings same as above **VT**, refer it.

VT By Level
-----------

**Command** and **Parameters** Settings same as above **VT**, refer it.

**File** option is used for the bin file selection, click button L0~L3 to set each level data bin file,

.. NOTE:: The default bin file under **C:\\Program Files (x86)\\FPGA Tester\\test_binfile**

.. image:: _static/60.png

VT By Bit Level
---------------

**Command** and **Parameters** Settings same as above **VT**, refer it.

**File** option is used for the bin file selection, click button L0~L3 to set each level data bin file,

.. NOTE:: The default bin file under **C:\\Program Files (x86)\\FPGA Tester\\test_binfile**

.. image:: _static/60.png




