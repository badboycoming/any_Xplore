Paragraph-level markup
======================
To describe some paragraph markup.

VERSION ADDED & CHANGED
-----------------------

.. versionadded:: 2.5

   The *spam* new version.

.. versionchanged:: 2.5.1

    This is a new changed version.

.. deprecated:: 2.4.9

    Use *spam* instead.

NOTE
----

.. note::
   This function is not suitable for sending spam e-mails.

WARNING
-------

.. warning::
   This function is not suitable for sending spam e-mails.

SEEALSO
-------

.. seealso::

   Module :py:mod:`zipfile`
       Documentation of the :py:mod:`zipfile` standard module.

   `GNU tar manual, Basic Tar Format <http://link>`_
       Documentation of the tar archive files, includeing GNU tar extensions.

RUBRIC
------

.. rubric:: title

HLIST
-----

.. hlist::
   :columns: 3

   * A list of
   * short items
   * that should be
   * displayed
   * horizontally

GLOSSARY
--------

.. glossary::

   environment
     A structure where information about all documents under the root us
     saved, and used for cross-referencing. The environment is pickled
     after the parsing stage, so that successive runs only need to read
     and parse new and changed documents.

   source directory
     The directory which, including its subdirectories, contains all
     source files for one Sphinx project.
    
   term 1
   term 2
     Definition of both terms.

   term 1 : a
   term 2 : b
     Definition of both terms, with label version.

Grammar production displays
---------------------------

.. productionlist::
   try_stmt: try1_stmt | try2_stmt
   try1_stmt: "try" ":" `suite`
            : ("except" [`expression` ["," `target`]] ":" `suite`)+
            : ["else" ":" `suite`]
            : ["finally" ":" `suite`]
   try2_stmt: "try" ":" `suite`
            : "finally" ":" `suite`

Showing code examples
---------------------

Default Python code snippet::

    try:
        fhi = open('an_not_exist_file', 'r')
    except IOError, e:
        print '*** ERROR: %s' % str(e)
    else:
        for line in fhi:
            print line,
    finally:
        fhi.close()

For C code snippet,

.. code-block:: c

   #include <stdio.h>

   int main(int argc, char * argv[])
   {
       printf("Hello sphinx!\n");
       return 0;
   }

Again, for C code snippet,

.. sourcecode:: c

   #include <stdio.h>

   int main(int argc, char * argv[])
   {
       printf("Hello sphinx!\n");
       return 0;
   }

For C++ code snippet,

.. sourcecode:: c++

   #include <iostream>
   //using namespace std;

   int main()
   {
       /* cout << "Hello sphinx!" << endl; */
       std::cout << "Hello sphinx!" << std::endl;
       return 0;
   }

For guess code snippet,

.. sourcecode:: guess

   #include <iostream>
   //using namespace std;

   int main()
   {
       /* cout << "Hello sphinx!" << endl; */
       std::cout << "Hello sphinx!" << std::endl;
       return 0;
   }

