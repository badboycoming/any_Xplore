This is a Title
===============
That has a paragraph about a main subject and is set when the '='
is at least the same length of the title itself.

Subject Subtitle
----------------
Subtitles are set with '-' and are required to have the same length
of the subtitle itself, just like titles.

Lists can be unnumbered like:

 * Item Foo
 * Item Bar

Or automatically numbered:

 #. Item Apple
 #. Item Banana

Inline Markup
-------------
Words can have *emphasis in italics* or be **bold** and you can define
code samples with back quotes, like when you talk about a command: ``sudo``
gives you super user powers!

Following is an example on how to link image:

.. image:: _static/facebook.png

Function Demo
-------------
We have described some user defined API, for example you can see the :py:func:`enumerate_my` function, and the 
:py:func:`max_my` function. You also can find the oppsite Python official function such as :py:func:`enumerate`
, :py:func:`max`.


