reStructuredText Explore
========================
To list all avaliable demo of reStructuredText.

Inline Makeup
-------------

one asterisk for emphasis: *italics*

two asterisk for strong emphasis: **boldface**

backquotes for code samples: ``print 'Hello world!'``

subscriptis use: H\ :sub:`2`\ O

superscriptis use: 2\ :sup:`10`\  = 1024

.. [LoR] http://www.qq.com
.. [TD] http://www.sina.com


Lists and Quote-like blocks
---------------------------

* This is a bulleted list.
* It has two items, the second item uses two lines.

1. This is a numbered list.
2. It has two items too.

#. This is a numbered list.
#. It has two items too.

Nested lists
------------

* Good good study, day day up.
* Day day study, good good up.

  * with a nested list
  * and some subitems

* and here the parent list continues


Blackberry
    Blackberry is not a kind of fruit, it is a eletronics company.

    Which is an Canada company.

Apple
    Apple is an America company, not a fruit company too.

A poem (to demo preserve line break)
    | Hold fast to dreams,
    | For if dream die,
    | Life is a broken-wing bird,
    | That cannot fly.

Source code
-----------

This is a normal text paragraph. The next paragraph is a code sample::

    try:
        fhi = open('./haimingwei.txt', 'r')
    except IOError, res:
        print '*** ERROR: %s' % str(res)
    else:
        for line in fhi:
            print line,
    finally:
        fhi.close()

This is a normal text paragraph again.

Simple table
------------

======  ========  =======
  A       B       A and B
======  ========  =======
False   1. False   False
        #. ok
        #. nok
True    False     1. True
                  #. ok
                  #. nok
======  ========  =======

Grid table
----------

+----------------------------+------------+------------+------------+
| | Head row, column 1       | | Header 2 | | Header 3 | | Header 4 |
| | (header rows optional)   | |          | |          | |          |
+============================+============+============+============+
| body row 1, column 1       | column 2   |   column 3 |   column 4 |
+----------------------------+------------+------------+------------+
| body row 2                 | ...        | ...        |            |
+----------------------------+------------+------------+------------+

External link
-------------

| The Tencent official website is: http://www.qq.com
| And the Service email address: services@qq.com

And this is an implicit link: `QQ is here <http://www.qq.com>`_

And this is another implicit link: `QQ is here`_.

.. _QQ is here: http://www.qq.com

Footnotes
---------

| Lorem ipsum [#f1]_ dolor sit amet ... [#f2]_
| Good study [#]_ day day up [#]_

Citations
---------

| The lord of rings [LoR]_.
| Crouching Tiger Hidden Dragon [TD]_.

Comments
--------
Two comments style, use **..**

.. #. Good good study, day day up. Again
.. #. Day day study, good good up.
.. 
..   #. with a nested list
..   #. and some subitems
.. 
.. #. and here the parent list continues


.. #. Good good study, day day up. Again
   #. Day day study, good good up.
 
     #. with a nested list
     #. and some subitems
 
   #. and here the parent list continues

Auxilary
--------

.. rubric:: Footnotes

.. [#f1] Text of the first footnote.
.. [#f2] Text of the second footnote.
.. [#] About the study.
.. [#] About the up.




