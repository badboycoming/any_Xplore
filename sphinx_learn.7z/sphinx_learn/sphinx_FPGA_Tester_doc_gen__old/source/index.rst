.. FPGA Tester documentation master file, created by
   sphinx-quickstart on Thu Dec  7 09:55:52 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

FPGA Tester documentation
===========================

.. toctree::
   :maxdepth: 6
   :caption: Contents:

   cheatsheet.rst
   example.rst
   pythonapi.rst
   reStructuredText_explor.rst
   sections.rst
   paragraphMakeup.rst

.. --> additional options for toc
   :numbered:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


