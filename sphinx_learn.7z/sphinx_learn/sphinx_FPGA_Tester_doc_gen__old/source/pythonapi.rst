Python API
==========
This paragraph is used to describe the basic python API.

User Defined API
----------------

.. py:function:: enumerate_my(sequence[, start=0])

    Return an iterator that yields tuples of an index and an item of the *sequence*. (And so on.)

.. function:: max_my(iterable[, key=func])

    With a single iterable argument, return its largest item.


