#!/usr/bin/env python

import Image

#im = Image.open('./address.png')
#im.thumbnail((18, 18))
#im.save('./address_1616.png', 'png')

#im = Image.open('./help.png')
#im.thumbnail((18, 18))
#im.save('./help_1616.png', 'png')

#im = Image.open('./ip.png')
#im.thumbnail((18, 18))
#im.save('./ip_1616.png', 'png')

#im = Image.open('./log.png')
#im.thumbnail((18, 18))
#im.save('./log_1616.png', 'png')

#im = Image.open('./trim.png')
#im.thumbnail((18, 18))
#im.save('./trim_1616.png', 'png')

#im = Image.open('./vt.png')
#im.thumbnail((18, 18))
#im.save('./vt_1616.png', 'png')

