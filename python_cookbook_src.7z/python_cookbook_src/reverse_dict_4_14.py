#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Reverse dict.
##############################################################################

def dict_reverse(d):
    return dict([ (v, k) for k, v in d.items() ])

def dict_reverse_fast(d):
    # return dict([ (v, k) for k, v in d.iteritems() ])

    import itertools
    return dict( itertools.izip( d.itervalues(), d.iterkeys() ) )


if __name__ == '__main__':

    d = {'a': 'apple', 'b': 'blackberry', 'w': 'water'}
    print dict_reverse(d)
    print dict_reverse_fast(d)




