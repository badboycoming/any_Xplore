#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Purpose: Dispose character one by one.
##############################################################################

"""
>>> s = 'hello world!'

>>> list(s)
['h', 'e', 'l', 'l', 'o', ' ', 'w', 'o', 'r', 'l', 'd', '!']


>>> for ch in s:
	print ch,

h e l l o   w o r l d !


>>> [ch for ch in s]
['h', 'e', 'l', 'l', 'o', ' ', 'w', 'o', 'r', 'l', 'd', '!']


>>> import string
>>> map(string.upper, s)
['H', 'E', 'L', 'L', 'O', ' ', 'W', 'O', 'R', 'L', 'D', '!']


>>> [ch.upper() for ch in s]
['H', 'E', 'L', 'L', 'O', ' ', 'W', 'O', 'R', 'L', 'D', '!']


>>> set(s)
set(['!', ' ', 'e', 'd', 'h', 'l', 'o', 'r', 'w'])

"""





