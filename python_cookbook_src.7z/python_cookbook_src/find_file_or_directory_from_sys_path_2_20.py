#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Find file or directory from sys.path.
##############################################################################

import sys
import os

class NotFoundError(Exception):
    pass

def _find(name, matchFunc=os.path.isfile):
    for dir in sys.path:
        candidate = os.path.join(dir, name)
        if matchFunc(candidate):
            return candidate
    raise NotFoundError("Can't find %s!" % name)

def findFile(filename):
    return _find(filename)

def findDir(dirname):
    return _find(dirname, matchFunc=os.path.isdir)


if __name__ == '__main__':

    print findFile('glob.py')
    print findDir('wx')



