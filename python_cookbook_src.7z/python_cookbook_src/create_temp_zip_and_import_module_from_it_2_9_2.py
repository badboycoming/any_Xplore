#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Create temp zip file, and import module from it.
##############################################################################

import zipfile
import tempfile
import os
import sys


if __name__ == '__main__':

    # create temp zip file
    handle, filename = tempfile.mkstemp(suffix='.zip')
    # print 'filename =', filename
    os.close(handle)

    # write a file to zip archive
    z = zipfile.ZipFile(filename, 'w')
    z.writestr('hello.py', 'def f(): return "Hello world from " + __file__')
    z.close()

    # import module from zip archive
    sys.path.insert(0, filename)
    import hello
    print hello.f()
    os.unlink(filename)




