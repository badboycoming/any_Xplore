#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Create a subdict from a dict and key list.
##############################################################################

def sub_dict(dic, key_list):  # not change original dic
    return dict([ (k, dic.get(k)) for k in key_list ])

def sub_dict_e(dic, key_list):  # change original dic
    return dict([ (k, dic.pop(k, None)) for k in key_list ])

##### if one key in key list but not in dic, following throw exception,

def sub_dict_thrw(dic, key_list):  # not change original dic
    # return dict([ (k, dic.get(k)) for k in key_list ])
    return dict([ (k, dic[k]) for k in key_list ])

def sub_dict_e_thrw(dic, key_list):  # change original dic
    # return dict([ (k, dic.pop(k, None)) for k in key_list ])
    return dict([ (k, dic.pop(k)) for k in key_list ])

##### if one key in key list but not in dic, following just ignore that key,

def sub_dict_ignr(dic, key_list):  # not change original dic
    # return dict([ (k, dic.get(k)) for k in key_list ])
    # return dict([ (k, dic[k]) for k in key_list ])
    return dict([ (k, dic[k]) for k in key_list if k in dic ])

def sub_dict_e_thrw(dic, key_list):  # change original dic
    # return dict([ (k, dic.pop(k, None)) for k in key_list ])
    # return dict([ (k, dic.pop(k)) for k in key_list ])
    return dict([ (k, dic.pop(k)) for k in key_list if k in dic ])

if __name__ == '__main__':

    dic = {'a': 'apple', 'b': 'blackberry', 'w': 'water'}

    sub = sub_dict(dic, 'awx')
    print 'original dic =', dic
    print 'new sub dic =', sub

    print '\nAfter sub_dict_e,'
    sub_e = sub_dict_e(dic, 'awx')
    print 'original dic =', dic
    print 'new sub dic =', sub






