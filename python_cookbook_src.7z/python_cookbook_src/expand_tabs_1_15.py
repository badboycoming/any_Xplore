#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# expand tabs.
##############################################################################

"""
>>> s = '|\t\tgood\t|'

>>> s.expandtabs(4)
'|       good    |'



# a little re.split trick

>>> s = 'Have a nice day'

>>> import re

>>> re.split(r'a', s)
['H', 've ', ' nice d', 'y']

>>> re.split(r'(a)', s)
['H', 'a', 've ', 'a', ' nice d', 'a', 'y']

"""
