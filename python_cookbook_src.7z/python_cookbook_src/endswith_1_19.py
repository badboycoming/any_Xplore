#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# check endswith.
##############################################################################

# a heavy method
def endsWith_heavy(s, *endings):

    for item in endings:
        if s.endswith(item):
            return True
    return False

#-----------------------------------------------------------------------------

import itertools

def anyTrue(predicate, sequence):
    return True in itertools.imap(predicate, sequence)

def endsWith_advance(s, *endings):
    return anyTrue(s.endswith, endings)


if __name__ == '__main__':

    import os
    current_list = os.listdir('.')
    for item in current_list:
        if endsWith_heavy(item, ('.png', '.txt')):
            print item

    print

    for item in current_list:
        if endsWith_advance(item, ('.png', '.txt')):
            print item





