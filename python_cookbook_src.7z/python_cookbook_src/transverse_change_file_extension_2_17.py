#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Transverse change file extension.
##############################################################################

import os

def swap_extension(dir, before, after):

    if before[0] != '.':
        before = '.' + before
    thelen = -len(before)

    if after[0] != '.':
        after = '.' + after

    for path, subdirs, files in os.walk(dir):
        for oldfile in files:
            if oldfile[thelen:] == before:
                oldfilepath = os.path.join(path, oldfile)
                newfilepath = oldfilepath[:thelen] + after
                os.rename(oldfilepath, newfilepath)

if __name__ == '__main__':

    swap_extension('.', 'data', 'bin')

