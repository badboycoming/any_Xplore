#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# exchange between unicode string and common string.
##############################################################################

# unicodeString = u'Hello world!'
unicodeString = u'宁静致远'

#######################################
# convert unicode string to byte stream
#######################################

# asciiByteStream = unicodeString.encode('ascii')       # can only used to encode ascii, not common used
# isoByteStream = unicodeString.encode('iso-8859-1')    # can only used to encode latine, not common used
utf8ByteStream = unicodeString.encode('utf-8')
utf16ByteStream = unicodeString.encode('utf-16')

# print 'asciiByteStream =', asciiByteStream
# print 'isoByteStream =', isoByteStream
print 'utf8ByteStream =', utf8ByteStream
print 'utf16ByteStream =', utf16ByteStream


#######################################
# convert byte stream to unicode string
#######################################
plainString_utf8ByteStream = utf8ByteStream.decode('utf-8')
plainString_utf16ByteStream = utf16ByteStream.decode('utf-16')

# plainString_utf8ByteStream = unicode(utf8ByteStream, 'utf-8')
# plainString_utf16ByteStream = unicode(utf16ByteStream, 'utf-16')

print 'plainString_utf8ByteStream =', plainString_utf8ByteStream
print 'plainString_utf16ByteStream =', plainString_utf16ByteStream







