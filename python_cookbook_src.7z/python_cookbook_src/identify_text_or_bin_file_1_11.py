#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
To identify if a file is text or bin.
"""

# import pdb; pdb.set_trace()
import string

text_chars = ''.join([chr(val) for val in range(32, 127)]) + '\n\r\t\b'  # [32, 127) is printable characters

def istext(s, text_chars=text_chars, threadhold=0.3):

    # if '\0' in s:  # should be bin file, text file cannot contain '\0'
    #     return False

    if not s:  # s is empty, should be a text file, due to bin file cannot be empty
        return True

    all_chars = string.maketrans('', '')
    t = s.translate(all_chars, text_chars)  # get rid of all printable char in the s
    unprintableRatio = float(len(t)) / float(len(s))

    if unprintableRatio <= threadhold:
        return True, unprintableRatio
    else:
        return False, unprintableRatio


if __name__ == '__main__':

    # f = './t.txt'
    f = './t.png'

    # with open(f) as fhi:   # cannot use default 'r' to get all bin file contents..., but can use 'rb' to deal with txt file
    with open(f, 'rb') as fhi:
        s = fhi.read()
        text, ratio = istext(s)

        if text:
            print 'File unprintalble ratio is %.2f%% (<= empirical value 30%%)' % ratio
            print 'So, file is TEXT file.'
        else:
            print 'File unprintalble ratio is %.2f%% (> empirical value 30%%)' % ratio
            print 'So, file is Bin file.'







