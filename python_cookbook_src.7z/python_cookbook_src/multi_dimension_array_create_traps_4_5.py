#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Multi-dimension array created traps.
##############################################################################

"""
>> a = [0]
>> b = a * 5
>> b
[0, 0, 0, 0, 0]
>> b[0] = 1
>> b
[1, 0, 0, 0, 0]
>> a
[0]
>>
>>
>> a = [0, 0]
>> b = [a] * 5
>> b
[[0, 0], [0, 0], [0, 0], [0, 0], [0, 0]]
>> b[0][0] = 1
>> b
[[1, 0], [1, 0], [1, 0], [1, 0], [1, 0]]
>> a
[1, 0]
>>
"""

import pprint

if __name__ == '__main__':

    ###########
    # wrong way
    ###########

    array_5_10 = [[0] * 10] * 5
    print 'at initial, array_5_10 is,'
    pprint.pprint(array_5_10)

    array_5_10[0][0] = 1
    print 'after modified, array_5_10 is,'
    pprint.pprint(array_5_10)
    print

    ###########
    # right way
    ###########

    array_5_10_ok = [[0 for col in range(10)] for row in range(5)]
    print 'at initial, array_5_10_ok is,'
    pprint.pprint(array_5_10_ok)

    array_5_10_ok[0][0] = 1
    print 'after modified, array_5_10_ok is,'
    pprint.pprint(array_5_10_ok)






