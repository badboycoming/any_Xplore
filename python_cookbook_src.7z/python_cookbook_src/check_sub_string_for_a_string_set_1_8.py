#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Purpose: check sub string from a string char set.
##############################################################################

"""
>>> def containsAny(sub, str_):
	for ch in sub:
		if ch in str_:
			return True
	else:
		return False

>>> containsAny('aeiou', 'bull shit!')
True



>>> def containsAny_ver2(sub, str_):
	return bool(set(sub) & set(str_))

>>> containsAny_ver2('aeiou', 'bull shit!')
True



>>> def containsAny_ver3(sub, str_):
	import string
	transTable = string.maketrans('', '')
	return len(str_) != len(str_.translate(transTable, sub))

>>> containsAny_ver3('aeiou', 'bull shit!')
True


"""
