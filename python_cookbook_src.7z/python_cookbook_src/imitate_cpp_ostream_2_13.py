#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# To imitate cpp ostream.
##############################################################################

class IOManipulator(object):
    def __init__(self, function=None):
        self.function = function
    def do(self, output):
        self.function(output)

def do_endl(stream):
    stream.output.write('\n')
    stream.output.flush()

endl = IOManipulator(do_endl)

#-----------------------------------------------------------------------------

class OStream(object):
    def __init__(self, output=None):
        if output is None:
            import sys
            output = sys.stdout
        self.output = output
        self.format = '%s'
    def __lshift__(self, thing):
        if isinstance(thing, IOManipulator):
            thing.do(self)
        else:
            self.output.write(self.format % thing)
            # self.format = '%s'  # not understand why ???
        return self

if __name__ == '__main__':
    cout = OStream()
    cout << 'The average of ' << 1 << ' and ' << 3 << ' is ' << (1+3)/2 << endl
    cout << 'Hello world!'
    cout << 'Have a good time!' << endl





