#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Write file.
##############################################################################

import random
import struct
import sys

def write_a_random_file(filename, mode, size):
    """
    :param filename: user specify name, *.txt or *.bin for text file or binary file seperately.
    :param mode: 'w' or 'wb' for text file or binary file seperately.
    :param size: file size in byte.
    :return: None
    """
    # generate random bytes
    # random_list = range(100)  # test
    random_list = []
    for loop in range(size):
        random_list.append(random.randint(0, 255))

    if mode == 'wb':
        # pack the data to string-byte
        random_list = [struct.pack('>B', val) for val in random_list]
    elif mode == 'w':
        def hex_advance(val):
            hex_str = hex(val)
            if len(hex_str) == 3:  # like 0x0, 0x1, etc.
                hex_str = hex_str[:2] + '0' + hex_str[-1]
            return hex_str[-2:]

        random_list = ''.join([hex_advance(n) for n in random_list])
    else:
        sys.exit(-1)

    # write to file
    fho = open(filename, mode)
    for item in random_list:
        fho.write(item)
    fho.close()

if __name__ == '__main__':

    write_a_random_file('./random.bin', 'wb', 1024)
    # write_a_random_file('./random.txt', 'w', 1024)






