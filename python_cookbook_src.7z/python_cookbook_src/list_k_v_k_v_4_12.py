#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Convert list to key, value, key, value, ...
##############################################################################

def list_to_dict(lis):
    lis_k = lis[::2]
    lis_v = lis[1::2]
    # return dict(zip(lis_k, lis_v))
    import itertools
    return dict(itertools.izip(lis_k, lis_v))

def list_to_dict_iter(lis):
    def pair_wise(seq):
        itr = iter(seq).next
        while True:
            yield itr(), itr()
    return dict(pair_wise(lis))


if __name__ == '__main__':
    lis = range(10)
    print list_to_dict(lis)
    print list_to_dict_iter(lis)





