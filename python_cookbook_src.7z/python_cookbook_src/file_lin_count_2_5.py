#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# file line count.
##############################################################################

def file_line_cnt_ver1(filepath):
    with open(filepath) as fhi:
        return len(fhi.readlines())

def file_line_cnt_ver2(filepath):  # for big file
    with open(filepath) as fhi:
        for lineNum, lineContent in enumerate(fhi):
            pass
        return lineNum + 1

def file_line_cnt_ver3(filepath):
    cnt = 0
    with open(filepath, 'rb') as fhi:  # Note, here use rb
        while True:
            buf = fhi.read(65535)
            if not buf:
                break
            cnt += buf.count('\n')
        return cnt

#---------------------------------------------------------------

import time
def timeo(fun, *args, **kwargs):
    start = time.clock()
    for i in xrange(kwargs['n']):
        fun(args[0])
    end = time.clock()
    return fun.__name__, end-start

if __name__ == '__main__':

    print 'line count result,'
    print 'file_line_cnt_ver1 =', file_line_cnt_ver1('./t.txt')
    print 'file_line_cnt_ver2 =', file_line_cnt_ver2('./t.txt')
    print 'file_line_cnt_ver3 =', file_line_cnt_ver3('./t.txt')

    print timeo(file_line_cnt_ver1, './t.txt', n=10000)
    print timeo(file_line_cnt_ver2, './t.txt', n=10000)
    print timeo(file_line_cnt_ver3, './t.txt', n=10000)



