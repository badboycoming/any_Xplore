#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Calculate relative path to path.
##############################################################################

import os
import itertools
import pdb; pdb.set_trace()

def all_equal(elements):
    first_elem = elements[0]
    for other_elem in elements[1:]:
        if other_elem != first_elem:
            return False
    return True

def common_prefix(*sequences):
    if not sequences:
        return [], []
    common = []
    for elem in itertools.izip(*sequences):
        if not all_equal(elem):
            break
        common.append(elem[0])

    return common, [seque[len(common):] for seque in sequences]

def relpath(p1, p2, sep=os.path.sep, pardir=os.path.pardir):
    common, (u1, u2) = common_prefix(p1.split(sep), p2.split(sep))
    if not common:
        return p2  # if no common, then relpath is abspath
    return sep.join([pardir] * len(u1) + u2)


if __name__ == '__main__':
    print relpath('/a/b/c/d', '/a/b/x/y', '/')
    print relpath('/a/b/c/d', '/x/y/z', '/')
    print relpath('C:/x/y/z', 'D:/x/u/v', '/')

    print '==================================='
    print relpath('/a/b/c/d', '/a/b/c/d', '/')
    print '==================================='







