#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Search and replace within file.
##############################################################################

import os, sys

if __name__ == '__main__':

    nargs = len(sys.argv)
    if not 3 <= nargs <= 5:
        print 'Usage: %s search_text replace_text [infile [outfile]]' % os.path.basename(sys.argv[0])
    else:
        stext = sys.argv[1]
        rtext = sys.argv[2]
        input_file = sys.stdin
        output_file = sys.stdout
        if nargs > 3:
            input_file = open(sys.argv[3])
        if nargs > 4:
            output_file = open(sys.argv[4], 'w')

        # # if file is very big
        # for li in input_file:
        #     output_file.write(li.replace(stext, rtext))

        # if file is not too big (assume < 100MB)
        output_file.write(input_file.read().replace(stext, rtext))

        output_file.close()
        input_file.close()








