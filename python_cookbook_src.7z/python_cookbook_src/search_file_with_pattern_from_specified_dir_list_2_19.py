#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Search file with pattern, from specified dir list.
##############################################################################

import os
import glob

def all_matched_files(pattern, search_path_env_var):
    for path in search_path_env_var.split(os.pathsep):
        for m in glob.glob(os.path.join(path, pattern)):
            yield m

if __name__ == '__main__':
    search_path_env_var = os.pathsep.join('. ./test_for_transverse ./python_cookbook_src'.split())
    pattern = '*.txt'
    for f in all_matched_files(pattern, search_path_env_var):
        print f


