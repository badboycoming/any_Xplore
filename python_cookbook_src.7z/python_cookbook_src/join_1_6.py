#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Purpose: string join.
##############################################################################

"""
>>> ' '.join(['Have', 'a', 'good', 'time'])
'Have a good time'

>>> 'I want %d %s' % (3, 'apples')
'I want 3 apples'

>>> 'I also want {0} {1}'.format(1, 'watermelon')
'I also want 1 watermelon'

"""



