#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Random get byte.
##############################################################################

"""
Find a user specified byte from a bin file.
"""

def get_byte(theBinFile, byteIdx):
    fhi = open(theBinFile, 'rb')
    fhi.seek(byteIdx, 0)
    byte = fhi.read(1)
    fhi.close()

    import struct
    return hex(struct.unpack('>B', byte)[0])

if __name__ == '__main__':

    b = get_byte('./random.bin', 21)
    print 'The 21 byte is:', b



