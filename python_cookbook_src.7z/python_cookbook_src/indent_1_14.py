#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# indent.
##############################################################################

# import pdb; pdb.set_trace()

def reindent(s, numSpaces):

    leading_space = numSpaces * ' '
    lines = [leading_space + line.strip() for line in s.splitlines()]
    return '\n'.join(lines)

#-----------------------------------------------------------------------------

def addSpace(s, numAdd):

    white = ' ' * numAdd
    return white + white.join(s.splitlines(True))   # the 'white +' for the first line add white, NOTE: splitlines(True) reserve the '\n'

def numSpaces(s):
    # return [len(line) - len(line.lstrip()) for line in s.splitlines()]
    return [len(line) - len(line.lstrip()) for line in s.splitlines() if line.strip() != '']  # get rid of empty space

class DelTooManySpaceError(Exception): pass

def delSpace(s, numDel):
    if numDel > min(numSpaces(s)):
        raise DelTooManySpaceError, 'Removing more spaces than there are!'
    return '\n'.join([line[numDel:] for line in s.splitlines()])


if __name__ == '__main__':

    s = """
 Hold fast to dreams,
        for if dreams die,
      lif is a broken wing bird,
that cannot fly.
    """

    print 'Before:\n%s' %s
    print '\nAfter:\n%s' % reindent(s, 4)


    s = """
         <<Dreams>>
    Hold fast to dreams,
     For if dreams die,
      Life is a broken wing brid,
       That cannot fly.
       Hold fast to dreams,
      Fof if dreams go,
     Life is a barren field,
    Frozen with snow.
    """

    print '\nBefore:%s' % s
    print '\nAfter add 4 space for each:%s' % addSpace(s, 4)
    print '\nAfter remove 4 space for each:%s' % delSpace(s, 4)




