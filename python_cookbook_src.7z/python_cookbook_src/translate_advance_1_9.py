#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Advanced translate, only common string, not applied for Unicode string.
"""

import string

def translator(frm='', to='', delete='', keep=None):

    if len(to) == 1:
        to = to * len(frm)

    trans = string.maketrans(frm, to)

    # adjust the delete,
    if keep is not None:
        allchars = string.maketrans('', '')
        delete = allchars.translate(allchars, keep.translate(allchars, delete))

    def translate_(s):
        return s.translate(trans, delete)

    return translate_


if __name__ == '__main__':

    digit_only = translator(keep=string.digits)
    print digit_only('Mobile is: (+86) 15921063020')

    no_digit = translator(delete=string.digits)
    print no_digit('Mobile is: (+86) 15921063020')

    digit_to_hash = translator(frm=string.digits, to='#')
    print digit_to_hash('Mobile is: (+86) 15921063020')

    delete_priori_keep = translator(delete='abcd', keep='cdef')
    print delete_priori_keep('abcdef')






