#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Purpose: string align.
##############################################################################

"""
>>> s = 'Good day'

>>> s.ljust(20)
'Good day            '

>>> s.rjust(20)
'            Good day'

>>> s.center(20)
'      Good day      '


>>> s.ljust(20, '*')
'Good day************'

>>> s.rjust(20, '^')
'^^^^^^^^^^^^Good day'

>>> s.center(20, '+')
'++++++Good day++++++'


>>> ' Done '.center(20, '+')
'+++++++ Done +++++++'

"""





