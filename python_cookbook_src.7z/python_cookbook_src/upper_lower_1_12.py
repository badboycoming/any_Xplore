#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# To upper, lower, captialize, title, etc.
##############################################################################

"""
>>> s = 'Have a GOOd day.'

>>> s.upper()
'HAVE A GOOD DAY.'

>>> s.lower()
'have a good day.'

>>> s.capitalize()
'Have a good day.'

>>> s.title()
'Have A Good Day.'


>>> 'ABC'.isupper()
True

>>> 'abc'.islower()
True

>>> 'Good Man'.istitle()
True


#============================================>>> a function check if string capitalize, has defect

>>> def iscapitalized(s):
	return s.capitalize() == s

>>> iscapitalized('Have a good time')
True

>>> iscapitalized('')            # should return False, but not
True

>>> iscapitalized('\n\t\n\r')    # should return False, but not
True



#============================================>>> a more strict solution to check if string capitalize.

>>> import string

>>> def containAny(sub, str_):
	all_chars = string.maketrans('', '')
	return len(str_) != len(str_.translate(all_chars, sub))

>>> def iscapitalized_strict(s):
	return s == s.capitalize() and containAny(s, string.letters)  # the right condition to exclude s is empty or non-alpha


>>> iscapitalized_strict('Have a good time')
True

>>> iscapitalized_strict('')
False

>>> iscapitalized_strict('\n\r\b\t')
False


# But actually, still have a defect...

>>> iscapitalized_strict('\n\rb\t')
True

>>> s = '\n\rb\t'
>>> s.capitalize()
'\n\rb\t'

"""




