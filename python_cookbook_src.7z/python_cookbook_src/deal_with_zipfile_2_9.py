#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Deal with zip file.
##############################################################################

import zipfile

def check_zipfile_content_size(theFile):
    z = zipfile.ZipFile(theFile, 'r')  # NOTE, only can use 'r', NOT 'rb'
    for filename in z.namelist():
        bytes_stream = z.read(filename)
        print '\n<<<<<<<<<<<<<<<<<<<<<'
        print bytes_stream
        print '>>>>>>>>>>>>>>>>>>>>>'
        print 'File: %s has %d bytes.' % (filename, len(bytes_stream))

if __name__ == '__main__':

    check_zipfile_content_size('./demo.zip')




