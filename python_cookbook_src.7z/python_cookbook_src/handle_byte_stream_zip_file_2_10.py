#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Handle byte stream zip file.
##############################################################################

import cStringIO
import zipfile

class ZipString(zipfile.ZipFile):
    def __init__(self, byteStream, mode):
        # zipfile.ZipFile.__init__(self, file=cStringIO.StringIO(byteStream), mode=mode)
        super(self.__class__, self).__init__(file=cStringIO.StringIO(byteStream), mode=mode)


if __name__ == '__main__':

    # a stub method to generate bytestream, that bytestream content is an zip file
    fhi = open('./demo.zip', 'rb')
    byteStream = fhi.read()
    print '===================================== zip bytestream'
    print byteStream
    print '=====================================\n\n'

    # dispose the bytestream
    z = ZipString(byteStream, 'r')
    for filename in z.namelist():
        bytes_stream = z.read(filename)
        print '\n<<<<<<<<<<<<<<<<<<<<<'
        print bytes_stream
        print '>>>>>>>>>>>>>>>>>>>>>'
        print 'File: %s has %d bytes.' % (filename, len(bytes_stream))


