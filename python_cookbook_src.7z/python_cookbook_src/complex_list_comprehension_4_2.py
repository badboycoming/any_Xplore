#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Complex list comprehension.
##############################################################################
#
# But..I think use a function more clearly than list comprehension.
#
##############################################################################


def zero_less_than_five(lis):
    rtv = []
    for n in lis:
        if n < 5:
            rtv.append(0)
        else:
            rtv.append(n)
    return rtv


if __name__ == '__main__':

    lis = range(10)
    lis = [min(x, 0) if x < 5 else x for x in lis]
    print 'lis =', lis

    lis2 = range(10)
    lis2 = zero_less_than_five(lis2)
    print 'lis2 =', lis2





