#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# print unicode string to stdout.
##############################################################################

"""
Due to the stdout has it's own coding style, so if the unicode string not codec as the stdout, will get messy.

As following, understand the codecs,

In [1]: import codecs

In [2]: codecs.lookup('utf-8')
Out[2]: <codecs.CodecInfo object for encoding utf-8 at 0x3c0b468>

In [3]: list(codecs.lookup('utf-8'))
Out[3]:
[<function _codecs.utf_8_encode>,
 <function encodings.utf_8.decode>,
 <class encodings.utf_8.StreamReader at 0x0000000003C0B408>,
 <class encodings.utf_8.StreamWriter at 0x0000000003C0B3A8>]

"""

import codecs, sys
# sys.stdout = codecs.lookup('iso-8859-1')[-1](sys.stdout)
# sys.stdout = codecs.lookup('utf-16')[-1](sys.stdout)
sys.stdout = codecs.lookup('utf-8')[-1](sys.stdout)

unicodeString = u'\N{LATIN SMALL LETTER A WITH DIAERESIS}'
print unicodeString






