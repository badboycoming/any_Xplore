#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Purpose: string reverse.
##############################################################################

"""
>>> s = 'abcdefg'

>>> s[::-1]
'gfedcba'



>>> s = 'have a good time'

>>> ' '.join(reversed(s.split()))
'time good a have'

>>> ' '.join(s.split()[::-1])
'time good a have'



# NOTE: split, reserve whitespace
>>> s = 'have a \t good \n time'

>>> import re
>>> ''.join(re.split(r'(\s+)', s)[::-1])
'time \n good \t a have'



#--->>> NOET new point: regex split group
>>> re.split(r'\s+', s)
['have', 'a', 'good', 'time']

>>> re.split(r'(\s+)', s)
['have', ' ', 'a', ' \t ', 'good', ' \n ', 'time']

"""




