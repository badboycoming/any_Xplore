#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Make tar archive, compress with gzip or bzip2.
##############################################################################

import os
import tarfile

def make_tar(src_folder_to_backup, dest_folder, compressiopn=''):
    """
    :param src_folder_to_backup: better to use absolute path, but support relative path.
    :param dest_folder: if destination folder is not exists, create it first.
    :param compressiopn: should be 'gz' or 'bz2', if empty, just create tar archive.
    :return: archive path.
    """

    # create archive name
    if compressiopn != '':
        dest_ext = '.' + compressiopn
    else:
        dest_ext = ''
    dest_name = '%s.tar%s' % (os.path.basename(src_folder_to_backup), dest_ext)

    # create archive path
    if not os.path.exists(dest_folder):
        os.makedirs(dest_folder)
    dest_path = os.path.join(dest_folder, dest_name)

    # create tar package
    if compressiopn != '':
        mode = 'w:' + compressiopn
    else:
        mode = 'w'
    out = tarfile.TarFile.open(dest_path, mode)
    out.add(src_folder_to_backup)
    out.close()

    return dest_path


if __name__ == '__main__':

   print make_tar('./demo_targzipbz2_folder', '.')
   print make_tar('./demo_targzipbz2_folder', '.', 'gz')
   print make_tar('./demo_targzipbz2_folder', '.', 'bz2')






