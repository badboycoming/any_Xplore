#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Send binary stream to stdout, under MS-Windows.
##############################################################################

if __name__ == '__main__':

    # method 1
    fhi = open('./t.png', 'rb')
    byte_stream = fhi.read()
    print '==================================='
    print byte_stream
    print '===================================\n'
    fhi.close()

    # method 2
    import platform
    if platform.system() == 'Windows':
        import sys, os, msvcrt
        msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)   # set the line-end translation mode, can be os.O_TEXT, os.O_BINARY

    fhi = open('./t.png', 'rb')  # actually, the 'rb' mode will make the line-end to binary translation, so no need the above operation
    byte_stream = fhi.read()
    print '+++++++++++++++++++++++++++++++++++'
    sys.stdout.write(byte_stream)
    print '\n+++++++++++++++++++++++++++++++++++'






