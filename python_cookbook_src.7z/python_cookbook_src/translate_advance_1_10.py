#!/usr/bin/env python
# -*- coding: utf-8 -*-

import string

def makefilter(keep):

    allchars = string.maketrans('', '')
    delchars = allchars.translate(allchars, keep)

    def thefilter(s):
        return s.translate(allchars, delchars)

    return thefilter

def canonicform(s):

    allchars = string.maketrans('', '')
    return makefilter(s)(allchars)

##############################################################################-------------->>> prepare for understand the unicode translate.
# For Unicode objects, the translate() method does not accept the optional deletechars argument.
# Instead, it returns a copy of the s where all characters have been mapped through the given translation table
# which must be a mapping of Unicode ordinals to Unicode ordinals, Unicode strings or None.
# Unmapped characters are left untouched. Characters mapped to None are deleted.
# Note, a more flexible approach is to create a custom character mapping codec using the codecs module (see encodings.cp1251 for an example).
##############################################################################

class Keeper(object):
    def __init__(self, keep):
        self.keep = set([ord(ch) for ch in keep])

    def __getitem__(self, n):
        if n not in self.keep:
            return None  # char mapped to None are deleted
        return unichr(n)

    def __call__(self, s):
        return unicode(s).translate(self)

uni_makefilter = Keeper


if __name__ == '__main__':

    just_vowel = makefilter('aeiou')
    print just_vowel('Good good study, day day up!')
    print just_vowel('Have a nice day!')

    print
    print canonicform('bcdayzx')
    print

    uni_just_vowel = uni_makefilter(u'aeiou')
    print uni_just_vowel(u'Good good study, day day up!')
    print uni_just_vowel(u'Have a nice day!')





