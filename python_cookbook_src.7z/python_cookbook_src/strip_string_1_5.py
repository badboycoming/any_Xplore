#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Purpose: string strip.
##############################################################################

"""
>>> s = ' 	\n   Have a nice day! 	\n\n     '

>>> s
' \t\n   Have a nice day! \t\n\n     '

>>> s.lstrip()
'Have a nice day! \t\n\n     '

>>> s.rstrip()
' \t\n   Have a nice day!'

>>> s.strip()
'Have a nice day!'


NOTE: following remove specified char(s) from left and right side,

>>> s = 'xyxxyy hello yyx'

>>> s.strip('x')
'yxxyy hello yy'

>>> s.strip('y')
'xyxxyy hello yyx'

>>> s.strip('xy')
' hello '

"""





