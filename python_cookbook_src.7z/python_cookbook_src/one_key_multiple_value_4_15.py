#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# One key against multiple values.
##############################################################################

def word_dict(word_list):
    d = {}
    for w in word_list:
        d.setdefault(w, []).append(1)
    return d

if __name__ == '__main__':

    import re
    # # patt = r'([^\w]+)'  # ['good', ' ', 'good', ' ', 'study', ', ', 'day', ' ', 'day', ' ', 'up', '.', '']
    # patt = r'[^\w]+'      # ['good', 'good', 'study', 'day', 'day', 'up', '']
    # word_list = re.split(patt, 'good good study, day day up.')

    # patt = r'\w+'
    # word_list = re.search(patt, 'good good study, day day up.')
    # print word_list.group(0)

    patt = r'\w+'
    word_list = re.findall(patt, 'good good study, day day up.')
    # print word_list

    wd = word_dict(word_list)
    # print wd
    for k, v in wd.iteritems():
        print k, ': ', sum(v)
