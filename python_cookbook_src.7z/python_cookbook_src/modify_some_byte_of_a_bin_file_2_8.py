#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Modify some bytes of a bin file.
##############################################################################

import struct

def modify_bytes(theFileName, startIndex, bytesNum):
    """
    :param theFileName: bin file name
    :param startIndex: index to start change
    :param bytesNum: number of bytes to modified
    :return:
    """
    # fmt = {1:'>B', 2:'>2B', 4:'>4B', 8:'>8B'}
    fmt = '>' + str(bytesNum) + 'B'

    fh = open(theFileName, 'rb+')
    fh.seek(startIndex, 0)

    # read the orginal bytes data
    buf = fh.read(bytesNum)
    # print 'buf--->>>', buf

    # convert the byte stream into list
    fields = list(struct.unpack(fmt, buf))
    # print 'fields--->>>', fields

    # change these bytes, every bytes add 1
    fields = [n+1 for n in fields]

    # recover the byte stream
    buf = struct.pack(fmt, *fields)

    # write the byte stream into the bin file
    fh.seek(startIndex, 0)
    fh.write(buf)
    fh.close()


if __name__ == '__main__':

    modify_bytes('./random_bak.bin', 21, 3)

