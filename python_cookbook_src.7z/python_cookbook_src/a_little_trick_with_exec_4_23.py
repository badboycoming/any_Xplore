#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# execute in target dict.
##############################################################################

"""
>> d = {}
>> exec 'import sets as set' in d
>>
>> for k, v in d.iteritems():
	print '%-30s : %s' % (k, v)


__builtins__                   : {'bytearray': <type 'bytearray'>, 'IndexError': <type 'exceptions.IndexError'>, 'all': <built-in function all>}
set                            : <module 'sets' from 'C:\Python27\lib\sets.pyc'>
__warningregistry__            : {('the sets module is deprecated', <type 'exceptions.DeprecationWarning'>, 1): True}

"""
