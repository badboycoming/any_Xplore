#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# bind and unbind method.
##############################################################################

"""
>>> l = [1, 2, 3]

>>> x = l.append       # bind method

>>> x('good')
>>> l
[1, 2, 3, 'good']

>>> y = list.append    # unbind method

>>> y(l, 'nice')       # for unbind method, need an instance as parameter to invoke
>>> l
[1, 2, 3, 'good', 'nice']

>>> y('shit')          # error due to need an instance as 1st parameter

Traceback (most recent call last):
  File "<pyshell#29>", line 1, in <module>
    y('shit')
TypeError: descriptor 'append' requires a 'list' object but received a 'str'

"""
