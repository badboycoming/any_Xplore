#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Transverse a directory. Advance.
##############################################################################

import os
import fnmatch
# import pdb; pdb.set_trace()

def all_files(dir_path, patterns, single_level=False, yield_folder=False):
    """
    Transverse a directory, with specified patterns.
    :param dir_path: The root directory to transverse.
    :param patterns: pattern is used in fnmatch, can support *, ?, [seq], [!seq],
                     if have multiple pattern, should seperate with ';'
    :param single_level: if True, no recursion, else recursion.
    :param yield_folder: if True, output also have matched folder.
    :return: an iterator of match list.
    """
    patterns = patterns.split(';')
    for path, subdirs, files in os.walk(dir_path):
        if yield_folder:
            files.extend(subdirs)
        files.sort()
        for name in files:
            for patt in patterns:
                if fnmatch.fnmatch(name, patt):
                    yield os.path.join(path, name)
                    break
        if single_level:
            break

if __name__ == '__main__':

    # for f in all_files(dir_path='.', patterns='*.txt;*.html;*.bin'):
    # for f in all_files(dir_path='.', patterns='*.txt;*.html;*.bin', single_level=True):
    for f in all_files(dir_path='.', patterns='*.[Tt][Xx][Tt];*.[Hh][Tt][Mm][Ll];*.[Bb][Ii][Nn]'):  # if os filename case sensitive
        print f





