#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Simple adder.
##############################################################################

import decimal
import re
import operator

def help():
    print 'Enter a number and operator, an empty line to see the current subtotal,\n' \
          'or q to quit.\n'

def simple_adder():
    print '===================== Welcome to Adding Machine ====================='
    help()

    total = decimal.Decimal('0')

    # patt = re.compile(r"""
    #     (\d+\.?\d*)    # a int or float
    #     \s*            # maybe space
    #     ([-+*/])      # operator
    # """, re.VERBOSE)

    patt = re.compile(r"""(?x)
        (\d+\.?\d*)    # a int or float
        \s*            # maybe space
        ([-+*/])      # operator
    """)

    oper = {
        '+' : operator.add,
        '-' : operator.sub,
        '*' : operator.mul,
        '/' : operator.truediv,
    }

    while True:
        try:
            usr_input = raw_input().strip()
        except EOFError:  # read EOF
            usr_input = 'q'

        if not usr_input:  # read empty
            print '----------------\n', total
            continue
        elif usr_input == 'q':
            print '----------------\n', total
            break

        try:
            num_str, op = re.search(patt, usr_input).groups()
        except Exception:
            print 'Invalid entry: %r' % usr_input
            help()
            continue

        total = oper[op](total, decimal.Decimal(num_str))


if __name__ == '__main__':
    simple_adder()




