#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Set file property under MS-Windows.
##############################################################################

import win32con
import win32api
import os
import time

if __name__ == '__main__':
    thefile = 'testtesttest.txt'
    f = open(thefile, 'w')
    f.close()

    # hidden
    time.sleep(5)
    win32api.SetFileAttributes(thefile, win32con.FILE_ATTRIBUTE_HIDDEN)

    # read only
    time.sleep(5)
    win32api.SetFileAttributes(thefile, win32con.FILE_ATTRIBUTE_READONLY)

    # set to normal, for delete
    time.sleep(5)
    win32api.SetFileAttributes(thefile, win32con.FILE_ATTRIBUTE_NORMAL)
    os.remove(thefile)





