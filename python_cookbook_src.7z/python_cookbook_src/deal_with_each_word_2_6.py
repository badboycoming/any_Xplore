#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Deal with each word.
##############################################################################

"""
>>> s = 'now 10.5v'
>>> patt = re.compile(r"(\d+)\.(\d+)")
>>> m = re.search(patt, s)

>>> m
<_sre.SRE_Match object at 0x0000000002DFB8B0>
>>> m.group
<built-in method group of _sre.SRE_Match object at 0x0000000002DFB8B0>

>>> m.group()
'10.5'

>>> m.group(0)
'10.5'

>>> m.group(1)
'10'

>>> m.group(2)
'5'

"""


def with_split(s):
    return s.split()

def with_re(s):
    import re
    patt = re.compile(r"[\w'-]+")
    rtv_list = []
    for m in re.finditer(patt, s):
        rtv_list.append(m.group(0))
    return rtv_list

#-----------------------------------------------------------------------------

def words_of_file(thefilename, splitter=str.split):
    fhi = open(thefilename)
    for line in fhi:
        for wd in splitter(line):
            yield wd
    fhi.close()

def words_of_file_advance(thefilename):
    import re
    patt = re.compile(r"[\w'-]+")
    def splitter_advance(line):

        ############################################ ERROR, due to m.group(0) is already a single word
        # for m in re.finditer(patt, line):
        #     return m.group(0)
        ############################################

        return re.findall(patt, line)
    return words_of_file(thefilename, splitter=splitter_advance)

# def words_of_file(thefilename):
#     import re
#     patt = re.compile(r"[\w'-]+")
#
#     fhi = open(thefilename)
#     for line in fhi:
#         for m in re.finditer(patt, line):
#             yield m.group(0)
#     fhi.close()


if __name__ == '__main__':

    s = "It's a fine day in Chicago today, let's go-out-for a run."
    print 'with_split(s) =', with_split(s)
    print 'with_re(s) =', with_re(s)
    print

    for word in words_of_file('./t.txt'):
        print word,

    print

    for word in words_of_file_advance('./t.txt'):
        print word,





