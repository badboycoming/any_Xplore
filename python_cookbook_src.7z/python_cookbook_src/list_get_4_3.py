#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# To imitate dict.get(k, default)
##############################################################################

def list_get(lis, idx, default=None):

    # version 1

    # # if 0 <= idx < len(lis):  # bug
    # if -len(lis) <= idx < len(lis):
    #     return lis[idx]
    # return default

    # version 2
    try:
        return lis[idx]
    except IndexError:
        return default

#-----------------------------------------------------------------------------

class ListAdvance(list):

    # version 1

    # def get(self, idx, default=None):
    #     # if 0 <= idx < len(self):  # bug
    #     if -len(self) <= idx < len(self):
    #         return self[idx]
    #     return default

    # version 2

    def get(self, idx, default=None):
        try:
            return self[idx]
        except IndexError:
            return default


if __name__ == '__main__':

    dic = {'a': 'apple', 'w': 'water'}
    print dic.get('w', 'Blackberry')
    print dic.get('c', 'Blackberry')
    print

    li = range(5)
    print list_get(li, 3, None)
    print list_get(li, 4, None)
    print list_get(li, -1, None)
    print list_get(li, 5, None)
    print

    li2 = ListAdvance(range(5))
    print li2.get(3, None)
    print li2.get(4, None)
    print li2.get(-1, None)
    print li2.get(5, None)





