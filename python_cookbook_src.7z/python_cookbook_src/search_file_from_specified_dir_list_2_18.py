#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Search file from specified dir list.
##############################################################################

import os

def search_file(filename, search_path_env_var):
    for path in search_path_env_var.split(os.pathsep):
        candidate = os.path.join(path, filename)
        if os.path.isfile(candidate):
            return os.path.abspath(candidate)
    return None

if __name__ == '__main__':
    search_path_env_var = os.pathsep.join('. ./test_for_transverse ./python_cookbook_src'.split())
    filename = 'happy.txt'
    print search_file(filename, search_path_env_var)






