#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# string template.
##############################################################################

import string

if __name__ == '__main__':

    s = 'It is a find day in $city today, I want to go out for a $sport.'
    st = string.Template(s)

    # use dict as parameter
    print st.substitute({'city': 'Chicago', 'sport': 'Run'})
    # print st.substitute({'city': 'Chicago'})
    print st.safe_substitute({'city': 'Chicago'})
    print

    # use key word parameter
    print st.substitute(city='Chicago', sport='Run')
    # print st.substitute(city='Chicago')
    print st.safe_substitute(city='Chicago')
    print

    # use {} to gl the substitute and other chars
    print string.Template('I want each $num ${fruit}s.').substitute(num=3, fruit='apple')
    print

    # use locals() to collect all local vars
    msg = string.Template('The $number square is $val')
    for number in range(10):
        val = number ** 2
        # print msg.substitute(number=number, val=val)
        print msg.substitute(locals())
    print






