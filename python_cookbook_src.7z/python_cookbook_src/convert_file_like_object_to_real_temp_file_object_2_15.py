#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Convert file-like object to real temp file object.
#
# For Example:
#    urllib.urlopen() returns a file-like object, but marshal.load only can
#    dispose real file, so need to convert the file-like object to real file,
#    here save temp file for use.
##############################################################################

import types
import tempfile

def adapt_file(fileObj):
    if isinstance(fileObj, file):
        return fileObj

    tmpFileObj = tempfile.TemporaryFile()

    CHUNK_SIZE = 16 * 1024
    while True:
        data = fileObj.read(CHUNK_SIZE)
        if not data:
            break
        tmpFileObj.write(data)

    fileObj.close()
    tmpFileObj.seek(0)
    return tmpFileObj


if __name__ == '__main__':
    import urllib
    fhurl = urllib.urlopen('http://www.baidu.com')
    fhi = adapt_file(fhurl)
    for line in fhi:
        print line,


