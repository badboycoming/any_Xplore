#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# To upper, lower, captialize, title, etc.
##############################################################################

"""
>>> import string

>>> line = string.lowercase

>>> afield = line[3:8]
>>> line[3:8]
'defgh'


>>> import struct

>>> baseformat = '5s 3x 8s 8s'  # get 5 bytes, omit 3 bytes, get 8 bytes, get 8 bytes, and rest bytes

>>> numremain = len(line) - struct.calcsize(baseformat)

>>> format = '%s %ds' % (baseformat, numremain)

>>> s1, s2, s3, sr = struct.unpack(format, line)
>>> s1
'abcde'
>>> s2
'ijklmnop'
>>> s3
'qrstuvwx'
>>> sr
'yz'


>>> [line[idx:idx+5] for idx in range(0, len(line), 5)]
['abcde', 'fghij', 'klmno', 'pqrst', 'uvwxy', 'z']

"""

import string
import struct

def fields(baseformat, theline, lastfield=False):

    numremain = len(theline) - struct.calcsize(baseformat)
    format = '%s %d%s' % (baseformat, numremain, 's' if lastfield else 'x')

    return struct.unpack(format, theline)


def fields_memorizing(baseformat, theline, lastfield=False, _cache={}):   #----->>> Not understand how to improve efficiency

    key = baseformat, len(theline), lastfield
    format = _cache.get(key)
    if format is None:
        numremain = len(theline) - struct.calcsize(baseformat)
        _cache[key] = format = '%s %d%s' % (baseformat, numremain, 's' if lastfield else 'x')
    return struct.unpack(format, theline)


def split_by(theline, n, lastfield=False):

    pieces = [theline[k:k+n] for k in xrange(0, len(theline), n)]
    if not lastfield and len(pieces[-1]) < n:
        pieces.pop()
    return pieces


def split_at(theline, cuts, lastfield=False):

    pieces = [theline[i:j] for i, j in zip([0]+cuts, cuts+[None])]
    if not lastfield:
        pieces.pop()
    return pieces

#-------------------------------------------------------------------- use generator

def split_at_iter(theline, cuts, lastfield=False):
    last = 0
    for cut in cuts:
        yield theline[last:cut]
        last = cut

    if lastfield:
        yield theline[last:]

def split_by_iter(theline, n, lastfield=False):
    return split_at_iter(theline, xrange(n, len(theline), n), lastfield)


if __name__ == '__main__':

    theline = string.lowercase
    baseformat = '5s 3x 8s 8s'

    print '---->>> fields'
    rtv = fields(baseformat, theline)
    for item in rtv:
        print item

    print '\n---->>> fields, with last field'
    rtv = fields(baseformat, theline, True)
    for item in rtv:
        print item

    print '\n---->>> fields_memorizing'
    rtv = fields_memorizing(baseformat, theline)
    for item in rtv:
        print item

    print '\n---->>> split_by'
    rtv = split_by(theline, 5)
    for item in rtv:
        print item

    print '\n---->>> split_by, with last field'
    rtv = split_by(theline, 5, True)
    for item in rtv:
        print item

    print '\n---->>> split_at'
    rtv = split_at(theline, [8, 16, 20])
    for item in rtv:
        print item

    print '\n---->>> split_at_iter'
    rtv = split_at_iter(theline, [8, 16, 20])
    for item in rtv:
        print item

    print '\n---->>> split_by_iter'
    rtv = split_by_iter(theline, 5)
    for item in rtv:
        print item





