#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# sub str, replacement according to a dict.
##############################################################################

def expand(s, dic, marker='"', safe=False):

    if safe:
        def lookup(k):
            return dic.get(k, k.join(marker*2))
    else:
        def lookup(k):
            return dic[k]

    parts = s.split(marker)
    parts[1::2] = [lookup(k) for k in parts[1::2]]

    return ''.join(parts)


if __name__ == '__main__':

    s = 'It is a find day in *city* today, I want go out for a *sport*.'
    print expand(s, {'city':'Chicago'}, marker='*', safe=True)
    # print expand(s, {'city':'Chicago'}, marker='*', safe=False)


