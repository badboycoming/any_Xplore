#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Get specify line from a file.
##############################################################################

import linecache

def getline(thefilepath, getLineNumber):
    if getLineNumber < 1:
        return ''
    for lineNum, lineContent in enumerate(open(thefilepath)):
        if lineNum == getLineNumber-1:
            return lineContent
    return ''


if __name__ == '__main__':

    # use the module linecache is the easier way. NOTE, can use 'clearcache', 'checkcache' to handle the cache
    theLine = linecache.getline('./t.txt', 3)
    print 'The 3rd line is: [%s]' % theLine

    # use user defined function to handle big file
    theLine = getline('./t.txt', 3)
    print 'The user get 3rd line is: [%s]' % theLine





