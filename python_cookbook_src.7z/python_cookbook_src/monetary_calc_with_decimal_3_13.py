#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Monetary calculation with decimal.
##############################################################################

import decimal

def italformat(value, places=2, curr='EUR', sep=',', dp='.', pos='', neg='-', overall=10):
    """
    Convert Decimal value to monetary string.

    :param value: Decimal value.
    :param places: number of digits after decimal point.
    :param curr: money sign, 'EUR' etc, can be empty.
    :param sep: separator between triple digits, can be ',' or ' '
    :param dp: decimal point, should be '.', or ''(if places is 0)
    :param pos: '+' or ''
    :param neg: '-'
    :param overall: final string length, if not enough, padding with ' '
    :return: an monetray string.
    """

    q = decimal.Decimal((0, (1,), -places))
    sign, digits, exp = value.quantize(q).as_tuple()
    result = []
    digits = [str(n) for n in digits]

    # two shortcuts
    append = result.append
    next = digits.pop

    # accumulate after decimal point parts, in reverse order
    for i in range(places):
        if digits:
            append(next())
        else:
            append('0')
    append(dp)

    # accumulate before decimal point part, in reverse order
    i = 0
    while digits:
        append(next())
        i += 1
        if i == 3 and digits:
            i = 0
            append(sep)

    while len(result) < overall:
        append(' ')

    append(curr)

    if sign:
        append(neg)
    else:
        append(pos)

    result.reverse()
    return ''.join(result)

def getsubtotal(subtin=None):
    if subtin == None:
        subtin = input('Enter the subtotal: ')
    subtotal = decimal.Decimal(str(subtin))
    print "\n  subtotal:\t\t\t\t\t\t", italformat(subtotal)
    return subtotal

def cnpcalc(subtotal):
    contrib = subtotal * decimal.Decimal('0.02')
    print '+ contribute integrative 2%:', italformat(contrib, curr='')
    return contrib

def vatcalc(subtotal, cnp):
    vat = (subtotal + cnp) * decimal.Decimal('0.20')
    print '+ IVA 20%:\t\t\t\t\t', italformat(vat, curr='')
    return vat

def ritacalc(subtotal):
    rit = subtotal * decimal.Decimal('0.20')
    print '- Ritenuta accont 20%:\t\t', italformat(rit, curr='')
    return rit

def dototal(subtotal, cnp, iva=0, rit=0):
    tot = (subtotal + cnp + iva) - rit
    print '  TOTAL:\t\t\t\t\t\t', italformat(tot)
    return tot

####### final report

def invoice(subtotal=None, context=None):
    if context is None:
        decimal.getcontext().rounding = 'ROUND_HALF_UP'  # Euro round rule
    else:
        decimal.setcontext(context)
    subtot = getsubtotal(subtotal)
    contrib = cnpcalc(subtot)
    dototal(subtot, contrib, vatcalc(subtot, contrib), ritacalc(subtot))

if __name__ == '__main__':
    print 'Welcome to the invoice calculator'.center(50, '=')
    tests = [100, 1000.00, "10000", 555.43]

    print '\n----------------'
    print '  Euro context'
    print '----------------\n'
    for t in tests:
        invoice(t)

    print '\n------------------'
    print '  Default context'
    print '------------------\n'
    for t in tests:
        invoice(t, context=decimal.DefaultContext)





