#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Flatten a list tuple group.
##############################################################################
#
# Hard to understand... :(
#
##############################################################################

# import pdb; pdb.set_trace()

# def nonstring_iterable(obj):
#     try:
#         iter(obj)
#     except TypeError:
#         return False
#     else:
#         return not isinstance(obj, basestring)


def list_or_tuple(item):
    return isinstance(item, (list, tuple))

# recursion

def flatten_rec(seq, can_expand=list_or_tuple):
    for item in seq:
        if can_expand(item):
            for subitem in flatten(item, can_expand):
                yield subitem
        else:
            yield item

# non recursion

def flatten(seq, can_expand=list_or_tuple):
    itr = [iter(seq)]
    while itr:
        for item in itr[-1]:
            if can_expand(item):
                itr.append(iter(item))
                break
            else:
                yield item
        else:
            itr.pop()


if __name__ == '__main__':

    seq = [1, [2, (3, (4, [5, 6,[7, 8]])), 9, [10], 11], 12, [13]]

    for item in flatten_rec(seq):
        print item,
    print

    for item in flatten(seq):
        print item,




