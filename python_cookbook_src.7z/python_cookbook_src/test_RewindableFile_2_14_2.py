#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# File cache with buffer and can rewind, testbench.
##############################################################################

from file_cache_with_buffer_and_can_rewind_2_14 import RewindableFile
import urllib2
# import pdb; pdb.set_trace()

# infile = urllib2.urlopen('file:///C:/workspace/X_python/RewindableFile_Error_Feed.txt')
infile = urllib2.urlopen('file:///C:/workspace/X_python/RewindableFile_Good_Feed.txt')
infile = RewindableFile(infile)
s = infile.readline()
if s.startswith('ERROR:'):
    raise Exception(s[:-1])
############################################### if still use buffer, should disable the following two statements together
infile.seek(0)
infile.nobuffer()
###############################################
print infile.read()





