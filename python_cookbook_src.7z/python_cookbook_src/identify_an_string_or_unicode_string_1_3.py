#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Purpose: Identify a string, unicode string.
##############################################################################

"""
>>> s = 'good study'
>>> su = u'day up'


>>> def isAString(obj):                     # NOTE: cannot identify unicode string
	import types
	if type(obj) == types.StringType:
		return True
	else:
		return False

>>> isAString(s)
True
>>> isAString(su)
False



>>> def isAString2(obj):                    # NOTE: enough for common use, but cannot identify string-like derive from UserString
	if isinstance(obj, basestring):
		return True
	else:
		return False

>>> isAString2(s)
True
>>> isAString2(su)
True



>>> def isAString3(obj):                    # NOTE: the most complete solution, can identify UserString also
	try:
		obj + ''
	except:
		return False
	else:
		return True


>>> isAString3(s)
True
>>> isAString3(su)
True

"""

