#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Random pick elem with probability.
##############################################################################

"""
Not use assert in formal Python software, due to assert statement will be get rid of when optimization,
For example, following file t.py,

def test():
    assert 1 == 0
    print 'hello'


C:\Users\E901492\Desktop>python
Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license" for more information.
>>
>> import t
>> t.test()
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
  File "t.py", line 2, in test
    assert 1 == 0
AssertionError
>> exit()

C:\Users\E901492\Desktop>python -O
Python 2.7.13 (v2.7.13:a06454b1afa1, Dec 17 2016, 20:53:40) [MSC v.1500 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license" for more information.
>>
>> import t
>> t.test()
hello

"""

import random

def random_pick(seq, prob_list):  # according to probability

    # precheck.
    # But Note: the assert statement will be get rid of when optimization
    assert len(seq) == len(prob_list)
    assert min(prob_list) >= 0
    assert max(prob_list) <= 1
    assert abs(sum(prob_list) - 1) < 1e-5

    r = random.uniform(0, 1)
    prob_cum = 0.0
    for item, item_prob in zip(seq, prob_list):
        prob_cum += item_prob
        if r < prob_cum:  # means the item against this prob have bigger probability occure
            break
    return item

def random_pick_wei(seq, wei_list):  # according to weight

    # precheck.
    # But Note: the assert statement will be get rid of when optimization
    assert len(seq) == len(wei_list)

    all_collection_table = [z for x, y in zip(seq, wei_list) for z in [x] * y]
    random.shuffle(all_collection_table)
    while True:
        yield random.choice(all_collection_table)


if __name__ == '__main__':

    seq = [1, 2, 3, 4, 5]
    prob_target = [0.2, 0.1, 0.1, 0.4, 0.2]

    get_lis = []
    get_times = 200000
    for loop in xrange(get_times):
        get_lis.append(random_pick(seq, prob_target))

    prob_actual = []
    for item in seq:
        prob_actual.append( get_lis.count(item) / float(get_times) )

    print 'With {0} samples, probability get result:'.format(get_times)
    print 'Target   Actual'
    print '------   ------'
    for target, actual in zip(prob_target, prob_actual):
        print target, '<->', actual
    print

    seq2 = [1, 2, 3, 4, 5]
    # wei_target = [20, 10, 10, 40, 20]  # against with 100 percent
    wei_target = [20, 10, 10, 40, 30]    # not against with 100 precent, but against the weight
    get_lis2 = []
    get_times2 = 200000

    cnt = 0
    for val in random_pick_wei(seq2, wei_target):
        get_lis2.append(val)
        cnt += 1
        if cnt == get_times2:
            break

    wei_actual = []
    for item in seq2:
        wei_actual.append( get_lis2.count(item) / float(get_times2) )

    print 'With {0} samples, weight get result:'.format(get_times2)
    print 'Target   Actual'
    print '------   ------'
    for target, actual in zip(wei_target, wei_actual):
        print target, '<->', actual
    print





