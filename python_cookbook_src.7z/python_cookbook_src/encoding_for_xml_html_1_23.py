#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# encoding for xml and html.
##############################################################################

"""
In [6]: str.encode?
Docstring:
S.encode([encoding[,errors]]) -> object

Encodes S using the codec registered for encoding. encoding defaults
to the default encoding. errors may be given to set a different error
handling scheme. Default is 'strict' meaning that encoding errors raise
a UnicodeEncodeError. Other possible values are 'ignore', 'replace' and
'xmlcharrefreplace' as well as any other name registered with
codecs.register_error that is able to handle UnicodeEncodeErrors.
Type:      method_descriptor

"""

def encode_for_xml(unicode_data, encoding='ascii'):
    return unicode_data.encode(encoding, 'xmlcharrefreplace')

#-----------------------------------------------------------------------------

def encode_for_html(unicode_data, encoding='ascii'):
    return unicode_data.encode(encoding, 'html_replace')

import codecs
from htmlentitydefs import codepoint2name
def html_replace(exc):
    # print '---> exc =', exc               # test
    # print '---> exc.start =', exc.start   # test
    # print '---> exc.end =', exc.end       # test
    if isinstance(exc, (UnicodeEncodeError, UnicodeTranslateError)):
        s = [u'&%s;' % codepoint2name[ord(c)] for c in exc.object[exc.start:exc.end]]
        return ''.join(s), exc.end
    else:
        raise TypeError("Cann't handle %s" % exc.__name__)
codecs.register_error('html_replace', html_replace)


if __name__ == '__main__':

    data = u"""
<html>
    <head>
    <title>Encoding Test</title>
    </head>
    <body>
        <p>accented characters:
        <ul>
            <li>\xe0 (a + grave)
            <li>\xe7 (c + cedilla)
            <li>\xe9 (e + acute)
        </ul>
        <p>symbols:
        <ul>
            <li>\xa3 (British pound)
            <li>\u20ac (Euro)
            <li>\u221e (infinity)
        </ul>
    </body>
</html>
"""

    # print encode_for_xml(data)
    # print
    # print encode_for_html(data)
    with open('./encoding_xml.html', 'w') as fhoXml:
        fhoXml.write('%s' % encode_for_xml(data))
    with open('./encoding_html.html', 'w') as fhoHtml:
        fhoHtml.write('%s' % encode_for_html(data))

    data_chn = u"""
<html>
    <head>
    <title>Encoding Test</title>
    </head>
    <body>
        <p>accented characters (加重音):
        <ul>
            <li>\xe0 (a + grave)
            <li>\xe7 (c + cedilla)
            <li>\xe9 (e + acute)
        </ul>
        <p>symbols (货币符号):
        <ul>
            <li>\xa3 (British pound)
            <li>\u20ac (Euro)
            <li>\u221e (infinity)
        </ul>
    </body>
</html>
"""
    print encode_for_xml(data_chn)
    # print
    # print encode_for_html(data_chn)

    with open('./encoding_xml_chn.html', 'w') as fhoXmlChn:
        fhoXmlChn.write('%s' % encode_for_xml(data_chn))
    # with open('./encoding_html_chn.html', 'w') as fhoHtmlChn:
    #     fhoHtmlChn.write('%s' % encode_for_html(data_chn))


    ####################################################################################################################
    # NOTE: for common use, when write unicode string to file, database, network, should use 'encode' to convert it to
    #       unicode byte-stream first.
    #       If user or application need spcial coding style, like 'ascii' or 'latin-1', can use above encode_for_xml method.
    ####################################################################################################################

    with open('./original_chn_utf_8.html', 'w') as fhoOriChn:
        fhoOriChn.write('%s' % data_chn.encode('utf-8'))






