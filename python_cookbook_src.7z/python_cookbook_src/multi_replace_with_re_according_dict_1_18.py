#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# multiple replace with re, according dict.
##############################################################################

"""
>>> import re

>>> re.escape('abc*efg-xyz.uv+qq')
'abc\\*efg\\-xyz\\.uv\\+qq'
"""

import re

def multiple_replace(text, dic):
    patt = re.compile('|'.join([re.escape(k) for k in dic]))
    def repl(match):
        return dic[match.group(0)]
    return re.sub(patt, repl, text)

def multiple_replace_simple(text, dic):
    for k, v in dic.items():
        text = text.replace(k, v)
    return text

# make a translate closure
def make_translate(*args, **kwargs):
    dic = dict(*args, **kwargs)
    patt = re.compile('|'.join([re.escape(k) for k in dic]))
    def repl(match):
        return dic[match.group(0)]
    def xlat(text):
        return re.sub(patt, repl, text)
    return xlat

# define a class to deal
class make_xlate(object):
    def __init__(self, *args, **kwargs):
        self.dic = dict(*args, **kwargs)
        self.patt = self.make_patt()
    def make_patt(self):
        return re.compile('|'.join([re.escape(k) for k in self.dic]))
    def relp(self, match):
        return self.dic[match.group(0)]
    def __call__(self, text):
        return re.sub(self.patt, self.relp, text)

# the benefit to use class
class make_xlate_by_whole_words(make_xlate):
    def make_patt(self):  # to overrid to have new functional
        return re.compile(r'\b%s\b' % r'\b|\b'.join([re.escape(k) for k in self.dic]))


if __name__ == '__main__':

    text = 'Larry Wall is the creator of Perl.'
    dic = {'Larry Wall' : 'Guido van Rossum', 'Perl' : 'Python'}
    print multiple_replace(text, dic)
    print multiple_replace_simple(text, dic)

    translate = make_translate(dic)
    print translate(text)

    xlate = make_xlate(dic)
    print xlate(text)

    dic_wd = {'nice':'good', 'shit':'bad'}
    text_wd = 'What a nice day! Holly shit! nice day to have a run.'
    xlate_wd = make_xlate_by_whole_words(dic_wd)
    print xlate_wd(text_wd)




