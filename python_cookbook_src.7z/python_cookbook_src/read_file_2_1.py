#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Read file.
##############################################################################

"""
>>> fhi = open('t.txt')

>>> lis1 = fhi.readlines()  # reserve the '\n'
>>> fhi.seek(0,0)

>>> lis2 = fhi.read().split('\n')
>>> fhi.seek(0,0)

>>> lis3 = fhi.read().splitlines()

>>> for li in lis1:
...     print li
...
Hold fast to dreams,

for if dreams die,

life is a broken wing bird,

that cannot fly.



Hold fast to dreams,

for if dreams go,

life is a barren field,

frozon with snow.

>>> for li in lis2:
...     print li
...
Hold fast to dreams,
for if dreams die,
life is a broken wing bird,
that cannot fly.

Hold fast to dreams,
for if dreams go,
life is a barren field,
frozon with snow.

>>> for li in lis3:
...     print li
...
Hold fast to dreams,
for if dreams die,
life is a broken wing bird,
that cannot fly.

Hold fast to dreams,
for if dreams go,
life is a barren field,
frozon with snow.


########################################################################################################################
# NOTE: if open file failed, fhi is an undefined variable, so nothing bing to it, cannot use close() method on it.
#       so, for try-finally structure, should not put the open file statement into the try block.
########################################################################################################################

>>> fhi = open('t_not_exists.txt')
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
IOError: [Errno 2] No such file or directory: 't_not_exists.txt'

>>> fhi
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'fhi' is not defined

>>> fhi.close()
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
NameError: name 'fhi' is not defined


>>> fhi = open('t.txt')   # NOTE, do not put this statement into try block.
>>> try:
...     for li in fhi:
...         print li,
... finally:
...     fhi.close()
...
Hold fast to dreams,
for if dreams die,
life is a broken wing bird,
that cannot fly.

Hold fast to dreams,
for if dreams go,
life is a barren field,
frozon with snow.
>>>

"""

def read_file_by_chunks(filename, chunksize=20):
    fhi = open(filename, 'rb')
    while True:
        chunk = fhi.read(chunksize)
        if chunk == '':
            break
        yield chunk
    fhi.close()


if __name__ == '__main__':

    for chunk in read_file_by_chunks('./t.txt'):
        print chunk,












