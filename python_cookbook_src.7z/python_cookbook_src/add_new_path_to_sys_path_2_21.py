#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# Add new path to sys.path.
##############################################################################

"""
In [30]: sys.path
Out[30]:
['',
 'C:\\Python27\\Scripts\\ipython.exe',
 'C:\\Windows\\system32\\python27.zip',
 'c:\\python27\\DLLs',
 'c:\\python27\\lib',
 'c:\\python27\\lib\\plat-win',
 'c:\\python27\\lib\\lib-tk',
 'c:\\python27',
 'c:\\python27\\lib\\site-packages',
 'c:\\python27\\lib\\site-packages\\win32',
 'c:\\python27\\lib\\site-packages\\win32\\lib',
 'c:\\python27\\lib\\site-packages\\Pythonwin',
 'c:\\python27\\lib\\site-packages\\wx-3.0-msw',
 'c:\\python27\\lib\\site-packages\\IPython\\extensions',
 'C:\\Users\\kiterunner\\.ipython']

In [31]: sys.path[0]
Out[31]: ''

In [32]: os.path.abspath(sys.path[0])
Out[32]: 'C:\\workspace\\X_python'

In [33]: os.path.abspath('')
Out[33]: 'C:\\workspace\\X_python'

"""

import os
import sys
import platform

def addSysPath(new_path):

    new_path = os.path.abspath(new_path)

    if not os.path.exists(new_path):
        return -1

    if platform.system() == 'Windows':
        new_path = new_path.lower()

    for p in sys.path:
        if platform.system() == 'Windows':
            p = p.lower()
        if new_path in (p, p + os.sep):  # due to user path maybe  'C:/test' or 'C:/test/'
            return 0  # means new_path already in sys.path

    sys.path.append(new_path)
    # sys.path.insert(0, new_path)


if __name__ == '__main__':

    rtv = addSysPath('.')
    if rtv == 0:
        print 'Current directory is already in sys.path.'






