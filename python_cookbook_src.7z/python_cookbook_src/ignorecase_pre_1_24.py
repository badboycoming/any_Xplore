#!/usr/bin/env python
# -*- coding: utf-8 -*-
##############################################################################
# ignorecase list.
##############################################################################

import re

class iList(list):
    def count(self, *args, **kwargs):
        count_target = str(args[0])
        patt = re.compile(re.escape(count_target), re.IGNORECASE)
        tot = 0
        for idx in range(len(self)):
            if re.match(patt, str(self[idx])):
                tot += 1
        return tot


if __name__ == '__main__':

    il = iList((1, 2, 'book', 'BOOK', 3, 'Nice', 'bOOk', 'booK', 3, 'BooK', 3, 4, 5, 3))
    print "il.count('book') =", il.count('book')
    print "il.count('BOOK') =", il.count('BOOK')
    print "il.count('BooK') =", il.count('BooK')
    print "il.count(3) =", il.count(3)





