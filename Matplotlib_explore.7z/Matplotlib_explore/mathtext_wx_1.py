#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Demonstrates how to convert mathtext to a wx.Bitmap for display in various control on wxPython.
"""

import matplotlib
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg, NavigationToolbar2WxAgg, wxc, Figure
from numpy import arange, sin, cos, log, pi

import wx

IS_GTK = 'wxGTK' in wx.PlatformInfo
IS_WIN = 'wxMSW' in wx.PlatformInfo

##############################################################################
# This is where the 'magic' happends.
from matplotlib.mathtext import MathTextParser
mathtext_parser = MathTextParser('Bitmap')

def mathtext_to_wxbitmap(mathExpression):
    ftimage, depth = mathtext_parser.parse(s=mathExpression, dpi=150)
    return wxc.BitmapFromBuffer(ftimage.get_width(), ftimage.get_height(), ftimage.as_rgba_str())
##############################################################################

functions = [
    (r'$\sin(2 \pi x)$', lambda x: sin(2*pi*x)),
    (r'$\frac{4}{3} \pi x^3$', lambda x: (4.0/3.0)*pi*x**3),
    (r'$\cos(2 \pi x)$', lambda x: cos(2*pi*x)),
    (r'$\log(x)$', lambda x: log(x)),
]

class CanvasFrame(wx.Frame):

    def __init__(self, parent, title):
        super(self.__class__, self).__init__(parent=parent, id=-1, title=title, size=(550, 350))
        # self.SetBackgroundColour(wxc.NamedColour('WHITE'))
        self.SetBackgroundColour('sky blue')

        self.figure = Figure()
        self.axes = self.figure.add_subplot(111)

        self.canvas = FigureCanvasWxAgg(parent=self, id=-1, figure=self.figure)

        self.change_plot(0)  # means at the initial, draw the math text 0

        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.add_buttonbar()
        self.sizer.Add(item=self.canvas, proportion=1, flag=wx.ALL|wx.GROW, border=20)
        self.add_toolbar()

        menuBar = wx.MenuBar()

        # File Menu
        menu = wx.Menu()
        exitMenu = menu.Append(wx.ID_EXIT, 'E&xit\tAlt-X', 'Exit this simple sample')
        menuBar.Append(menu, '&File')
        self.Bind(event=wx.EVT_MENU, handler=self.OnClose, source=exitMenu)

        if IS_GTK or IS_WIN:
            # Equation menu
            menu = wx.Menu()
            for i, (mt, func) in enumerate(functions):
                bm = mathtext_to_wxbitmap(mt)
                item = wx.MenuItem(menu, 1000 + i)
                item.SetBitmap(bm)
                menu.AppendItem(item)
                self.Bind(wx.EVT_MENU, self.OnChangePlot, item)
            menuBar.Append(menu, '&Functions')

        self.SetMenuBar(menuBar)

        self.SetSizer(self.sizer)
        self.Fit()

    def OnClose(self, event):
        self.Close()

    def add_buttonbar(self):
        self.button_bar = wx.Panel(self)
        self.button_bar_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer.Add(self.button_bar, 0, wx.LEFT|wx.TOP|wx.GROW)

        for i, (mt, func) in enumerate(functions):
            bm = mathtext_to_wxbitmap(mt)
            button = wx.BitmapButton(parent=self.button_bar, id=1000 + i, bitmap=bm)
            self.button_bar_sizer.Add(item=button, proportion=1, flag=wx.GROW)
            self.Bind(event=wx.EVT_BUTTON, handler=self.OnChangePlot, source=button)

        self.button_bar.SetSizer(self.button_bar_sizer)

    def add_toolbar(self):
        """
        Copied verbatim from embedding_wx2.py
        """
        self.toolbar = NavigationToolbar2WxAgg(self.canvas)
        self.toolbar.Realize()
        # By adding toolbar in sizer, we are able to put it at the bottom of the frame,
        # so appearance is closer to GTK version.
        self.sizer.Add(item=self.toolbar, proportion=0, flag=wx.EXPAND)
        # update the axes menu on the toolbar
        self.toolbar.update()

    def OnChangePlot(self, event):
        self.change_plot(event.GetId() - 1000)

    def change_plot(self, plot_number):
        t = arange(1.0, 3.0, 0.01)
        s = functions[plot_number][1](t)
        self.axes.clear()
        self.axes.plot(t, s)
        self.canvas.draw()

class App(wx.App):

    def OnInit(self):
        frame = CanvasFrame(parent=None, title='wxPython mathtext demo app')
        frame.Show()
        self.SetTopWindow(frame)
        return True

if __name__ == '__main__':

    app = App()
    app.MainLoop()






