#!/usr/bin/env python
# -*- coding: utf-8 -*-

# matplotlib requires wxPython 2.8+
# uncomment following statements if you don't know exactly of your current wxPython version.
#-------------------------------------------------------------------------------
# import wxversion
# wxversion.ensureMinimal('2.8')
#-------------------------------------------------------------------------------

import wx
if 'phoenix' in wx.PlatformInfo:
    import wx.lib.agw.aui as aui
else:
    import wx.aui as aui

# import matplotlib as mpl
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg, NavigationToolbar2WxAgg, Figure

class Plot(wx.Panel):

    def __init__(self, parent, id=-1, dpi=None, **kwargs):
        super(self.__class__, self).__init__(parent=parent, id=id, **kwargs)

        self.figure = Figure(dpi=dpi, figsize=(2, 2))
        self.canvas = FigureCanvasWxAgg(parent=self, id=-1, figure=self.figure)
        self.toolbar = NavigationToolbar2WxAgg(canvas=self.canvas)
        self.toolbar.Realize()

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(item=self.canvas, proportion=1, flag=wx.EXPAND)
        sizer.Add(item=self.toolbar, proportion=0, flag=wx.EXPAND)
        self.SetSizer(sizer)

class PlotNotebook(wx.Panel):

    def __init__(self, parent, id=-1):
        super(self.__class__, self).__init__(parent=parent, id=id)

        self.nb = aui.AuiNotebook(self)
        sizer = wx.BoxSizer()
        sizer.Add(item=self.nb, proportion=1, flag=wx.EXPAND)
        self.SetSizer(sizer)

    def add(self, name='plot'):
        page = Plot(parent=self.nb)
        self.nb.AddPage(page, name)
        return page.figure

#-------------------------------------------------------------------------------

class App(wx.App):

    def OnInit(self):
        frame = wx.Frame(parent=None, id=-1, title='Plotter')

        plotter = PlotNotebook(frame)
        axes1 = plotter.add('figure 1').gca()
        axes1.plot([1, 2, 3], [2, 1, 4])
        axes2 = plotter.add('figure 2').gca()
        axes2.plot([1, 2, 3, 4, 5], [2, 1, 4, 2, 3])

        frame.Show()
        self.SetTopWindow(frame)
        return True

if __name__ == '__main__':

    app = App()
    app.MainLoop()




