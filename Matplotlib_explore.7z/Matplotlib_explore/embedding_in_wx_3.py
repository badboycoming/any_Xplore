#!/usr/bin/env python
# -*- coding: utf-8 -*-


#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
#       NOTE fully understand this using style.
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX


# XRC (XML wxWidgets resource) file to create GUI (made with XRCed)
# Thanks to matplotlib and wx teams for creating such great software!

from __future__ import print_function

# matplotlib requires wxPython 2.8+
# uncomment following statements if you don't know the exact version you are using.
#-------------------------------------------------------------------------------
# import wxversion
# wxversion.ensureMinimal('2.8')
#-------------------------------------------------------------------------------

import sys
import time
import os
import matplotlib
matplotlib.use('wxAgg')
import matplotlib.cm as cm  # colormap
import matplotlib.cbook as cbook

from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg, NavigationToolbar2WxAgg, Figure
import numpy as np

import wx
import wx.xrc as xrc

ERR_TOL = 1e-5  # floating point slop for peak-detection

matplotlib.rc('image', origin='lower')

class PlotPanel(wx.Panel):

    def __init__(self, parent):
        super(self.__class__, self).__init__(parent=parent, id=-1)

        self.fig = Figure(figsize=(5, 4), dpi=75)
        self.canvas = FigureCanvasWxAgg(parent=self, id=-1, figure=self.fig)
        self.toolbar = NavigationToolbar2WxAgg(self.canvas)  # matplotlib toolbar
        self.toolbar.Realize()
        # self.toolbar.set_active([0, 1])

        # now put all into a sizer
        sizer = wx.BoxSizer(wx.VERTICAL)
        # this way of adding to sizer allows resizing
        sizer.Add(item=self.canvas, proportion=1, flag=wx.ALL|wx.GROW)
        # best to allow the toolbar to resize
        sizer.Add(item=self.toolbar, proportion=0, flag=wx.GROW)
        self.SetSizer(sizer)
        self.Fit()

    def init_plot_data(self):

        a = self.fig.add_subplot(111)

        x = np.arange(120.0) * 2 * np.pi / 60.0
        y = np.arange(100.0) * 2 * np.pi / 50.0
        self.x, self.y = np.meshgrid(x, y)
        z = np.sin(self.x) + np.cos(self.y)
        self.im = a.imshow(z, cmap=cm.jet) #, interpolation='nearest')

        zmax = np.amax(z) - ERR_TOL
        ymax_i, xmax_i = np.nonzero(z >= zmax)
        if self.im.origin == 'upper':
            ymax_i = z.shape[0] -ymax_i
        self.lines = a.plot(xmax_i, ymax_i, 'ko')

        self.toolbar.update()

    def GetToolBar(self):
        # you will need to override GetToolBar if you are using an unmanaged toolbar in your frame
        return self.toolbar

    def OnWhiz(self, event):
        self.x += np.pi / 15
        self.y += np.pi / 20
        z = np.sin(self.x) + np.cos(self.y)
        self.im.set_array(z)

        zmax = np.amax(z) - ERR_TOL
        ymax_i, xmax_i = np.nonzero(z >= zmax)
        if self.im.origin == 'upper':
            ymax_i = z.shape[0] - ymax_i
        self.lines[0].set_data(xmax_i, ymax_i)

        self.canvas.draw()

    def OnEraseBackground(self, event):
        # this is supposed to prevent redraw flicker on some X servers...
        pass

#-------------------------------------------------------------------------------

class App(wx.App):

    def OnInit(self):
        xrcfile = cbook.get_sample_data('embedding_in_wx3.xrc', asfileobj=False)
        print('loading', xrcfile)

        self.res = xrc.XmlResource(xrcfile)

        # main frame and panel
        self.frame = self.res.LoadFrame(None, 'MainFrame')
        self.panel = xrc.XRCCTRL(self.frame, 'MainPanel')

        # matplotlib panel
        plot_container = xrc.XRCCTRL(self.frame, 'plot_container_panel')
        sizer = wx.BoxSizer(wx.VERTICAL)

        self.plotpanel = PlotPanel(plot_container)
        self.plotpanel.init_plot_data()

        sizer.Add(item=self.plotpanel, proportion=1, flag=wx.EXPAND)
        plot_container.SetSizer(sizer)

        whiz_button = xrc.XRCCTRL(self.frame, 'whiz_button')
        whiz_button.Bind(wx.EVT_BUTTON, self.plotpanel.OnWhiz)

        bang_button = xrc.XRCCTRL(self.frame, 'bang_button')
        bang_button.Bind(wx.EVT_BUTTON, self.OnBang)

        # final setup
        sizer = self.panel.GetSizer()
        self.frame.Show()
        self.SetTopWindow(self.frame)
        return True

    def OnBang(self, event):
        bang_count = xrc.XRCCTRL(self.frame, 'bang_count')
        bangs = bang_count.GetValue()
        bangs = int(bangs) + 1
        bang_count.SetValue(str(bangs))

if __name__ == '__main__':

    app = App()
    app.MainLoop()








