#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
An example of how to use wx or wxagg in an application with a custom toolbar.
"""

# matplotlib requires wxPython 2.8+
# uncomment following statements if you don't know exactly your wxpython version.
#-------------------------------------------------------------------------------
# import wxversion
# wxversion.ensureMinimal('2.8')
#-------------------------------------------------------------------------------

import matplotlib
matplotlib.use('wxAgg')
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg, NavigationToolbar2WxAgg, Figure
from matplotlib.backends.backend_wx import _load_bitmap

from numpy import arange, sin, pi
from numpy.random import rand

import wx

class MyNavigationToolbar(NavigationToolbar2WxAgg):
    """
    Extend the default wx toolbar with your own event handlers.
    """
    ON_CUSTOM = wx.NewId()

    def __init__(self, canvas):
        super(self.__class__, self).__init__(canvas=canvas)

        if 'phoenix' in wx.PlatformInfo:
            self.AddTool(self.ON_CUSTOM, 'Click me', _load_bitmap('qt4_editor_options.png'),
                         'Activate custom control')
            self.Bind(event=wx.EVT_TOOL, handler=self._on_custom, id=self.ON_CUSTOM)
        else:
            self.AddSimpleTool(self.ON_CUSTOM, _load_bitmap('qt4_editor_options.png'), 'Click me',
                               'Activate custom control')
            self.Bind(event=wx.EVT_TOOL, handler=self._on_custom, id=self.ON_CUSTOM)

            # NOTE: here only can use reverse oder to delete the tool, due to if not use reverse order, the position will
            # changed when you delete the first one.
            self.DeleteToolByPos(6)
            self.DeleteToolByPos(2)
            self.DeleteToolByPos(1)

    def _on_custom(self, event):
        """
        add some text to the axes in a random location in axes with a random color
        """
        # get the axes
        ax = self.canvas.figure.axes[0]

        # generate a random location can color
        x, y = tuple(rand(2))
        rgb = tuple(rand(3))

        # add the text and draw
        ax.text(x, y, 'You clicked me', transform=ax.transAxes, color=rgb)
        self.canvas.draw()
        event.Skip()

#-------------------------------------------------------------------------------

class CanvasFrame(wx.Frame):

    def __init__(self):
        super(self.__class__, self).__init__(parent=None, id=-1, title='Canvas Frame', size=(550, 350))

        self.figure = Figure(figsize=(5, 4), dpi=100)
        self.axes = self.figure.add_subplot(111)
        t = arange(0.0, 3.0, 0.01)
        s = sin(2 * pi * t)
        self.axes.plot(t, s)

        self.canvas = FigureCanvasWxAgg(parent=self, id=-1, figure=self.figure)

        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(item=self.canvas, proportion=1, flag=wx.ALL|wx.EXPAND)

        # capture the paint message
        self.Bind(event=wx.EVT_PAINT, handler=self.OnPaint)

        self.toolbar = MyNavigationToolbar(self.canvas)
        self.toolbar.Realize()
        self.sizer.Add(item=self.toolbar, proportion=0, flag=wx.ALL|wx.EXPAND)

        # update the axes menu on the toolbar
        self.toolbar.update()
        self.SetSizer(self.sizer)
        self.Fit()

    def OnPaint(self, event):
        self.canvas.draw()
        event.Skip()

class App(wx.App):

    def OnInit(self):
        frame = CanvasFrame()
        frame.Show()
        self.SetTopWindow(frame)
        return True

if __name__ == '__main__':

    app = App()
    app.MainLoop()




