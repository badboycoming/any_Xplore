#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
An example of how to use wx or wxagg in an application with the new toolbar.
"""

# Due to current script requires wxPython 2.8+, if you don't know which wxPython
# version you are using, uncomment following line.
#-------------------------------------------------------------------------------
# import wxversion
# wxversion.ensureMinimal('2.8')
#-------------------------------------------------------------------------------

import matplotlib

# Uncomment the following line to use wx rather than wxagg
#-------------------------------------------------------------------------------
# matplotlib.use('WX')
#-------------------------------------------------------------------------------

# Comment out following to use wx rather than wxagg
#-------------------------------------------------------------------------------
matplotlib.use('wxAgg')
#-------------------------------------------------------------------------------
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg, NavigationToolbar2WxAgg, Figure
from numpy import arange, sin, cos, pi

import wx

class CanvasFrame(wx.Frame):

    def __init__(self):
        super(self.__class__, self).__init__(parent=None, id=-1, title='CanvasFrame', size=(550, 350))

        self.figure = Figure()
        self.axes = self.figure.add_subplot(111)
        t = arange(0.0, 3.0, 0.01)
        s1 = sin(2 * pi * t)
        s2 = cos(2 * pi * t)

        self.axes.plot(t, s1, 'ro', label='sin(2*pi*t)')
        self.axes.plot(t, s2, 'bo', label='cos(2*pi*t)')
        # self.axes.plot(t, s1, color='#FFCCEE', linestyle='-', label='sin(2*pi*t)')
        # self.axes.plot(t, s2, color='b', linestyle='-.', label='cos(2*pi*t)')
        self.axes.set_title('Sin & Cos')
        self.axes.set_xlabel('t')
        self.axes.set_ylabel('y')
        self.axes.legend(loc='upper right')
        self.axes.grid()
        self.canvas = FigureCanvasWxAgg(parent=self, id=-1, figure=self.figure)

        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(item=self.canvas, proportion=1, flag=wx.EXPAND)
        self.SetSizer(self.sizer)
        self.Fit()

        self.add_toolbar()

    def add_toolbar(self):
        self.toolbar = NavigationToolbar2WxAgg(self.canvas)
        self.toolbar.Realize()
        self.sizer.Add(item=self.toolbar, proportion=0, flag=wx.EXPAND)
        # update the axes menu on the toolbar
        self.toolbar.update()

class App(wx.App):

    def OnInit(self):
        frame = CanvasFrame()
        frame.Show()
        self.SetTopWindow(frame)
        return True

if __name__ == '__main__':

    app = App()
    app.MainLoop()



