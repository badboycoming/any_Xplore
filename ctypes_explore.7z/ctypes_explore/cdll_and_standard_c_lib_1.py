#!/usr/bin/env python
# -*- coding: utf-8 -*-

from ctypes import *
import platform


def test_clib():

    if platform.system() == 'Windows':

        libc = cdll.LoadLibrary('msvcrt.dll')
        # libc = windll.LoadLibrary('msvcrt.dll')  # Windows only
        # libc = oledll.LoadLibrary('msvcrt.dll')  # Windows only
        # libc = pydll.LoadLibrary('msvcrt.dll')

        # libc = CDLL('msvcrt.dll')
        # libc = WinDLL('msvcrt.dll')  # Windows only
        # libc = OleDLL('msvcrt.dll')  # Windows only
        # libc = PyDLL('msvcrt.dll')

        # libc = cdll.msvcrt  # Windows only

    elif platform.system() == 'Linux':

        libc = cdll.LoadLibrary('libc.so.6')
        # libc = pydll.LoadLibrary('libc.so.6')

        # libc = CDLL('libc.so.6')
        # libc = PyDLL('libc.so.6')

    libc.printf('Hello ctypes!\n')


def test_mutable_val():

    v = c_int(12)
    print 'Before: v = %s, v.value = %d' % (v, v.value)
    v.value = 13
    print 'After:  v = %s, v.value = %d' % (v, v.value)


def test_immutable_str_val():

    ori_str = 'Hello world!'
    s = c_char_p(ori_str)
    print 'Before: s = %s, s.value = %s' % (s, s.value)
    s.value = 'Good day!'
    print 'After:  s = %s, s.value = %s' % (s, s.value)
    print 'ori_str = %s' % ori_str  # NOTE, the original memory has no change, due to it is immutable


def test_mutable_str_val():
    """
    Use 'create_string_buffer' to create mutable memory space. 'create_unicode_buffer' for C type wchar_t.
    """

    p = create_string_buffer(3)
    print 'sizeof(p) = %d, p.raw = %s' % (sizeof(p), repr(p.raw))
    p = create_string_buffer('Hello')
    print 'sizeof(p) = %d, p.raw = %s, p.value = %s' % (sizeof(p), repr(p.raw), repr(p.value))
    p = create_string_buffer('World', 10)
    print 'sizeof(p) = %d, p.raw = %s, p.value = %s' % (sizeof(p), repr(p.raw), repr(p.value))
    p.value = 'Hi'  # NOTE, here change affect the original memory
    print 'sizeof(p) = %d, p.raw = %s, p.value = %s' % (sizeof(p), repr(p.raw), repr(p.value))


def test_default_convert_type():
    """
    By default, integer, string, unicode string, no need to convert explicitly, other type should.
    """
    if platform.system() == 'Windows':
        libc = cdll.LoadLibrary('msvcrt.dll')
    elif platform.system() == 'Linux':
        libc = cdll.LoadLibrary('libc.so.6')

    # libc.printf('int = %d\n' % 12)            # NOTE, 'printf' with python style % is valid, but better to use c function style
    # libc.printf('long = %ld\n' % 1234567890)  # NOTE, 'printf' with python style % is valid, but better to use c function style
    libc.printf('int = %d\n', 12)
    libc.printf('long = %ld\n', 1234567890)
    libc.printf('string = %s\n', 'Hello world!')
    libc.printf('unicode string = %S\n', u'Good day')

    libc.printf('int = %d\n', c_int(12))
    libc.printf('long = %ld\n', c_long(1234567890))
    libc.printf('string = %s\n', c_char_p('Hello world!'))
    libc.printf('unicode string = %S\n', c_wchar_p(u'Good day'))

    # libc.printf('float = %f\n', 3.14159)           # ctypes ArgumentError
    # libc.printf('float = %f\n', c_float(3.14159))  # float = 0.000000 , why ??
    libc.printf('float = %f\n', c_double(3.14159))


def test_call_function_with_custom_data_type():

    if platform.system() == 'Windows':
        libc = cdll.LoadLibrary('msvcrt.dll')
    elif platform.system() == 'Linux':
        libc = cdll.LoadLibrary('libc.so.6')

    class Bottles(object):
        def __init__(self, val):
            self._as_parameter_ = val  # NOTE, ctypes looks for _as_parameter_ attribute and use this as function parameter, should be inter, string, unicode string.

    bottles = Bottles(12)
    libc.printf('I have drink %d bottles beer!\n', bottles)


def test_call_function_with_custome_data_type2():

    if platform.system() == 'Windows':
        libc = cdll.LoadLibrary('msvcrt.dll')
    elif platform.system() == 'Linux':
        libc = cdll.LoadLibrary('libc.so.6')

    class Bottles(object):
        def __init__(self, val):
            # self._as_parameter_ = val  # NOTE, ctypes looks for _as_parameter_ attribute and use this as function parameter, should be inter, string, unicode string.
            self._val = val

        @property
        def val(self):
            return self._val

    bottles = Bottles(12)
    libc.printf('I have drink %d bottles beer!\n', bottles.val)


def test_specify_required_argument_types_and_return_type_for_function():

    if platform.system() == 'Windows':
        libc = cdll.LoadLibrary('msvcrt.dll')
        libmy = cdll.LoadLibrary('powX.dll')
    elif platform.system() == 'Linux':
        libc = cdll.LoadLibrary('libc.so.6')
        libmy = cdll.LoadLibrary('powX.so')

    libc.printf.argtypes = [c_char_p, c_char_p, c_int, c_double]
    libc.printf("String '%s', Int %d, Double %f\n",
                "Hi",
                10,
                2.2)

    libc.strchr.argtypes = [c_char_p, c_char]
    libc.strchr.restype = c_char_p
    print 'Find str is: %s' % libc.strchr('abcdef', 'd')

    libmy.powX.argtypes = [c_float, c_float]   # specify the function arguments types
    libmy.powX.restype = c_float               # Note: also need to specify the return value type, if need to use the return value
    print 'Pow rtv is: %f' % libmy.powX(2, 10)


def test_passing_pointers_by_ref():

    if platform.system() == 'Windows':
        libc = cdll.LoadLibrary('msvcrt.dll')
        libmy = cdll.LoadLibrary('powX.dll')
    elif platform.system() == 'Linux':
        libc = cdll.LoadLibrary('libc.so.6')
        libmy = cdll.LoadLibrary('powX.so')

    i = c_int()
    f = c_float()
    s = create_string_buffer(10)

    print 'Begin, i.value = %d, f.value = %f, s.value = %s, s.raw=%s' % (i.value, f.value, s.value, repr(s.raw))
    libc.sscanf("55 3.14 Hello", "%d %f %s", byref(i), byref(f), s)
    print 'After, i.value = %d, f.value = %f, s.value = %s, s.raw=%s' % (i.value, f.value, s.value, repr(s.raw))

    iX = c_int(66)
    print 'Begin, iX.value = %d' % iX.value
    libmy.doubleX(byref(iX))
    print 'After, iX.value = %d' % iX.value


def test_structure_and_union():

    class Point(Structure):  # should derive from ctypes.Structure
        _fields_ = [('x', c_int),  # should define the field
                    ('y', c_int)]

    class Rect(Structure):
        _fields_ = [('upperleft', Point),
                    ('upperright', Point)]

    p1 = Point(12, 13)
    p2 = Point(12, 28)
    rc = Rect(p1, p2)

    print 'rc upperleft: (%d, %d)' % (rc.upperleft.x, rc.upperleft.y)
    print 'rc upperright: (%d, %d)' % (rc.upperright.x, rc.upperright.y)

    if platform.system() == 'Windows':
        libmy = cdll.LoadLibrary('powX.dll')
    elif platform.system() == 'Linux':
        libmy = cdll.LoadLibrary('powX.so')

    pV = Point(15, 16)
    print 'Begin: pV.x = %d, pV.y = %d' % (pV.x, pV.y)
    libmy.doubleStructElem(byref(pV))
    print 'After: pV.x = %d, pV.y = %d' % (pV.x, pV.y)


def test_structure_and_union_bit_fields():

    class INT(Structure):
        _fields_ = [('first_4', c_uint, 4),
                    ('second_2', c_uint, 2)]

    i = INT(15, 3)
    print i.first_4
    print i.second_2

    print '-' * 20

    i2 = INT(16, 4)
    print i2.first_4
    print i2.second_2

    print '-' * 20

    i3 = INT(17, 5)
    print i3.first_4
    print i3.second_2


def test_array():

    TenIntArray_1D = c_int * 10  # create array contains 10 c_int value

    ta1 = TenIntArray_1D()
    print 'for default initial,'
    for idx, value in enumerate(ta1):
        print idx, '<->', value

    ta2 = TenIntArray_1D(1, 2, 3, 0, 6, 1, 7, 9, 5, 1)
    print 'for initial with value,'
    for idx, value in enumerate(ta2):
        print idx, '<->', value

    if platform.system() == 'Windows':
        libmy = cdll.LoadLibrary('powX.dll')
    elif platform.system() == 'Linux':
        libmy = cdll.LoadLibrary('powX.so')

    ta3 = TenIntArray_1D(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    libmy.double1DArray(byref(ta3), c_int(len(ta3)))
    print 'After called C double,'
    for idx, value in enumerate(ta3):
        print idx, '<~>', value


def test_pointer():

    i = c_int(42)
    pi = pointer(i)  # use ctypes.pointer to define a pointer
    print '1st, pi.contents =', pi.contents
    i = c_int(55)
    print '2nd, only change i to c_int(55), pi.contents =', pi.contents
    pi.contents = i
    print '3rd, change pi.contents to i, pi.contents =', pi.contents
    pi.contents = c_int(78)
    print '4th, change pi.contents to c_int(78), i =', i
    print "-------------------------- Above means, with properties 'contents', no influence each other."

    i2 = c_int(39)
    pi2 = pointer(i2)
    print '1st, pi2.contents =', pi2.contents
    print '1st, pi2[0] =', pi2[0]
    pi2[0] = 77
    print '2nd, after change pi2[0] to 77, i2 =', i2  # NOTE, only in this way [], pointer can change original value
    i2 = c_int(99)
    print '3rd, after change i2 to c_int(99), pi2[0] =', pi2[0]

    #------------------------------------------------

    pInt = POINTER(c_int)  # define a c_int type pointer
    pInt(c_int(123))  # initial the pointer
    pInt = None  # set pointer to NULL

    pInt2 = POINTER(c_int)()  # create a NULL pointer


def test_type_conversion():

    class Bar(Structure):
        _fields_ = [('count', c_int),
                    ('values', POINTER(c_int))]

    b = Bar()
    b.cout = 3
    b.values = (c_int * 3)(5, 9, 6)  # here auto convert
    for idx in range(b.cout):
        print b.values[idx]

    b.values = cast((c_byte * 4)(), POINTER(c_int))  # force conversion with ctypes.cast
    print 'after cast:', b.values[0]


def test_incomplete_type():

    # class cell(Structure):
    #     _fields_ = [('name', c_char_p),
    #                 ('next', POINTER(cell))]  # Nok, NameError: free variable 'cell' referenced before assignment in enclosing scope

    class cell(Structure):
        pass

    cell._fields_ = [('name', c_char_p),
                     ('next', POINTER(cell))]  # Note, here define attribute _fields_ later than the Structure cell, so is ok

    c1 = cell()
    c1.name = 'foo'
    c2 = cell()
    c2.name = 'bar'

    c1.next = pointer(c2)
    c2.next = pointer(c1)

    p = c1
    for loop in range(10):
        print p.name,
        p = p.next[0]


def test_pass_python_function_to_C_with_CFUNCTYPE():

    if platform.system() == 'Windows':
        libc = cdll.LoadLibrary('msvcrt.dll')
    elif platform.system() == 'Linux':
        libc = cdll.LoadLibrary('libc.so.6')

    #-----------------------------------------------------------------------
    # CFUNCTYPE(restype, *argtypes, **kw)
    cmpFuncType = CFUNCTYPE(c_int, POINTER(c_int), POINTER(c_int))

    def py_cmp_func(a, b):
        # if a[0] > b[0]:
        #     return 1
        # elif a[0] < b[0]:
        #     return -1
        # else:
        #     return 0

        if a.contents > b.contents:
            return 1
        elif a.contents < b.contents:
            return -1
        else:
            return 0

    cmpfunc = cmpFuncType(py_cmp_func)
    #-----------------------------------------------------------------------

    IntArray5 = c_int * 5
    ia = IntArray5(99, 55, 3, 1, 2)
    print 'Before sort, ia is:'
    for item in ia:
        print item,

    # void qsort (void * base, size_t num, size_t size, int (*compar)(const void *, const void *));
    libc.qsort(ia, len(ia), sizeof(c_int), cmpfunc)

    print '\nAfter sort, ia is:'
    for item in ia:
        print item,

def test_keng():

    class Point(Structure):
        _fields_ = [('x', c_int),
                    ('y', c_int)]
    class Rect(Structure):
        _fields_ = [('upperLeft', Point),
                    ('upperRight', Point)]

    p1 = Point(1, 5)
    p2 = Point(9, 7)
    rc = Rect(p1, p2)

    print 'Before: rc.upperLeft.x = %d, rc.upperLeft.y = %d, rc.upperRight.x = %d, rc.upperRight.y = %d' % \
          (rc.upperLeft.x, rc.upperLeft.y, rc.upperRight.x, rc.upperRight.y)

    rc.upperLeft, rc.upperRight = rc.upperRight, rc.upperLeft

    print 'After: rc.upperLeft.x = %d, rc.upperLeft.y = %d, rc.upperRight.x = %d, rc.upperRight.y = %d' % \
          (rc.upperLeft.x, rc.upperLeft.y, rc.upperRight.x, rc.upperRight.y)

    ############# result as,
    # Before: rc.upperLeft.x = 1, rc.upperLeft.y = 5, rc.upperRight.x = 9, rc.upperRight.y = 7
    # After: rc.upperLeft.x = 9, rc.upperLeft.y = 7, rc.upperRight.x = 9, rc.upperRight.y = 7
    #############


def test_resize():
    """
    Actually, resize is useless method.
    """
    short_array = (c_short * 4)(1, 2, 3, 4)
    print 'sizeof(short_array) =', sizeof(short_array)  # get 8, means short_array take 8-byte memory
    print 'len(short_array) =', len(short_array)
    print 'before resize, short_array is: ',
    for idx in range(len(short_array)):
        print short_array[idx],
    print

    try:
        resize(short_array, 4)  # resize short_array to 4-byte, raise error, due to cannot resize smaller than original
    except ValueError, e:
        print 'ERROR: %s' % str(e)

    resize(short_array, 32)
    print 'after succeed resize to 32-byte, now sizeof(short_array) =', sizeof(short_array)
    print 'after succeed resize to 32-byte, now len(short_array) =', len(short_array)
    print 'after reszie, short_array is: ',
    for idx in range(len(short_array)):
        print short_array[idx],

    print "\n\n*** NOTE *** after resize to 32-byte, short_array still as 4 short elements array, \n" \
          "************ cannot get access to the new allocated space... Official documents says this...shit!"


if __name__ == '__main__':

    # test_clib()
    # test_mutable_val()
    # test_immutable_str_val()
    # test_mutable_str_val()
    # test_default_convert_type()
    # test_call_function_with_custom_data_type()
    # test_call_function_with_custome_data_type2()
    # test_specify_required_argument_types_and_return_type_for_function()
    # test_passing_pointers_by_ref()
    # test_structure_and_union()
    # test_structure_and_union_bit_fields()
    # test_array()
    # test_pointer()
    # test_type_conversion()
    # test_incomplete_type()
    # test_pass_python_function_to_C_with_CFUNCTYPE()
    # test_keng()
    test_resize()




