//----------------------------------------------------------------------------
// Purpose: this c module is used to speed up the Python program, should be 
//          compiled into dll, and then load into Python module with ctypes
//          method.
//
// Compile Methods:
//
//    ======================
//    Windows: use MSVC, x64
//    ======================
//
//    C:\Program Files (x86)\Microsoft Visual Studio 12.0\VC\bin\amd64> cd /d Path\to\target_C_file_folder
//    Path\to\target_C_file_folder> cl /LD needforspeed.c /o nfs.dll
//
//    ======
//    Linux:
//    ======
//     
//    $ gcc -fPIC -shared needforspeed.c -o nfs.so
//----------------------------------------------------------------------------

#include <stdio.h>
#include <math.h>  // pow()

// Windows need this compile direction for dll compilation, Linux no need 
#ifdef _MSC_VER
    #define DLL_EXPORT __declspec( dllexport ) 
#else
    #define DLL_EXPORT
#endif

DLL_EXPORT float powX(float a, float b) {
    return pow(a, b);
}

DLL_EXPORT void doubleX(int * v) {
    *v = *v * 2;
}

typedef struct {
    int m;
    int n;
} MN;

DLL_EXPORT void doubleStructElem( MN * pMN)
{
    pMN->m *= 2;
    pMN->n *= 2;
}

DLL_EXPORT void double1DArray(int arr[], int len)
{
	for(int idx = 0; idx < len; idx++)
		arr[idx] *= 2;
}



