#!/usr/bin/env python
# -*- coding: utf-8 -*-

def sayHi():
    print 'Hi, How are you friend?'

def simpleMod(m, n):
    return m % n



