// This is a test for check insert the Python statements or module in C.

#include "Python.h"

int main(void)
{
    // execute python statements
    /*
    Py_Initialize();
    PyRun_SimpleString("import os");
    PyRun_SimpleString("print os.getcwd()");
    //PyRun_SimpleString("os.chdir(r'C:\\Program Files (x86)\\FPGA Tester')");
    //PyRun_SimpleString("os.system('FPGA_Tester_GUI.exe')");
    Py_Finalize();
    */

    // execute python module
    Py_Initialize();
    PyRun_SimpleString("import sys");
    PyRun_SimpleString("sys.path.append('.')");
    PyObject * pModule = NULL;
    PyObject * pFunc = NULL;
    pModule = PyImport_ImportModule("hello");
    pFunc = PyObject_GetAttrString(pModule, "sayHi");
    PyEval_CallObject(pFunc, NULL);
    Py_Finalize();

    return 0;
}



