// Purpose: C code, for wrappered.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int fact(int n)
{
    if(n < 2)
        return 1;
    return n * fact(n - 1);
}

char * reverse(char * s)
{
    char t;
    char *p = s;
    char *q = (s + (strlen(s) - 1));
    
    while(p < q)
    {
        t = *p;
        *p++ = *q;
        *q-- = t;
    }

    return s;
}

// just for unit test, for the two function above
void unit_test(void)
{
    // test fact()
    printf("4! = %d\n", fact(4));
    printf("8! = %d\n", fact(8));
    printf("12! = %d\n", fact(12));

    // test reverse
    char s[10] = "abcdef";
    printf("reversing 'abcdef', we get '%s'\n", reverse(s));
    char s2[10] = "madam";
    printf("reversing 'madam', we get '%s'\n", reverse(s2));
}


