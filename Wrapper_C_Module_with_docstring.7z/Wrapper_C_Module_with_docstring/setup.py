#!/usr/bin/env python

from distutils.core import setup, Extension

MOD = 'ExtDemo'
setup(name=MOD, ext_modules=[
    Extension(MOD, sources=['ExtDemo.c', "ExtDemo_Wrapper.c"])])


