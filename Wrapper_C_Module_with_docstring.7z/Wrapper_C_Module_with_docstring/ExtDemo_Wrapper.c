// Purpose: According to the C code, write the Wrapper.

#include "Python.h"

// function declaration

int fact(int n);
char * reverse(char * s);
int unit_test(void);


//static PyObject * ExtDemo_fact(PyObject * self, PyObject * args)
//{
//    int res;              // parse result
//    int num;              // arg for fac()
//    PyObject * retval;    // return value
//
//    res = PyArg_ParseTuple(args, "i", &num);
//    if (!res)             // TypeError
//    {
//        return NULL;
//    }
//    res = fact(num);
//    retval = (PyObject *)Py_BuildValue("i", res);
//    return retval;
//}

static PyObject * ExtDemo_fact(PyObject * self, PyObject * args)
{
    int num;
    if(!PyArg_ParseTuple(args, "i", &num))
        return NULL;
    return (PyObject *)Py_BuildValue("i", fact(num));
}


static PyObject * ExtDemo_reverse(PyObject * self, PyObject * args)
{
//    char * orig_str;
//    char * dupe_str;
//    PyObject * retval;
//    if (!PyArg_ParseTuple(args, "s", &orig_str))
//        return NULL;
//
//    retval = (PyObject *)Py_BuildValue("ss", orig_str, dupe_str=reverse(strdup(orig_str)));  // strdup no ok in Windows?
//    free(dupe_str);
//    return retval;

    char * orig_str;
    if (!PyArg_ParseTuple(args, "s", &orig_str))
        return NULL;
    return (PyObject *)Py_BuildValue("s", reverse(orig_str));
}

static PyObject * ExtDemo_unit_test(PyObject * self, PyObject * args)
{
    unit_test();
    //return (PyObject *)Py_BuildValue("");
    Py_INCREF(Py_None);
    return Py_None;
}

//////////////////////////////////////////////////////////////////////////////

static PyMethodDef ExtDemoMethods[] = {
    //{"fact", ExtDemo_fact, METH_VARARGS, "fact(m) to calculate the factorial of m."},
    //{"reverse", ExtDemo_reverse, METH_VARARGS, "reverse(str) to output the reversed of str."},
    //{"unit_test", ExtDemo_unit_test, METH_VARARGS, "unit_test() for test all valid methods."},
    
    {"fact", ExtDemo_fact, METH_VARARGS, "fact( m )"},
    {"reverse", ExtDemo_reverse, METH_VARARGS, "reverse( str )"},
    {"unit_test", ExtDemo_unit_test, METH_VARARGS, "unit_test()"},
    {NULL, NULL, 0, NULL},  /* Sentinel */
};

//////////////////////////////////////////////////////////////////////////////

PyMODINIT_FUNC initExtDemo()
{
    Py_InitModule("ExtDemo", ExtDemoMethods);
}


